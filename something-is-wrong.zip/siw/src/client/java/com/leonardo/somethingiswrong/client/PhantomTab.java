package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * "Jogador fantasma" na lista Tab. Apenas visual e apenas neste cliente: adiciona/remove uma entrada
 * local na lista de jogadores. Os campos privados sao localizados pelo TIPO generico (Map<UUID, PlayerListEntry>
 * e Collection<PlayerListEntry>), nao pelo nome, para funcionar em qualquer mapeamento; se algo falhar, nada acontece.
 */
public final class PhantomTab {
    private static final Map<String, PlayerListEntry> ACTIVE = new HashMap<>();

    private PhantomTab() {}

    private static UUID idFor(String name) {
        return UUID.nameUUIDFromBytes(("somethingiswrong:phantom:" + name).getBytes(StandardCharsets.UTF_8));
    }

    public static void add(MinecraftClient client, String name) {
        try {
            ClientPlayNetworkHandler handler = client.getNetworkHandler();
            if (handler == null || ACTIVE.containsKey(name)) return;
            UUID id = idFor(name);
            PlayerListEntry entry = new PlayerListEntry(new GameProfile(id, name), false);
            Map<UUID, PlayerListEntry> map = findMap(handler);
            if (map == null) return;
            map.put(id, entry);
            Collection<PlayerListEntry> listed = findListed(handler);
            if (listed != null) listed.add(entry);
            ACTIVE.put(name, entry);
        } catch (Throwable t) {
            SomethingIsWrongMod.LOGGER.warn("Nao foi possivel mostrar o jogador fantasma no Tab: {}", t.toString());
        }
    }

    public static void remove(MinecraftClient client, String name) {
        try {
            PlayerListEntry entry = ACTIVE.remove(name);
            ClientPlayNetworkHandler handler = client.getNetworkHandler();
            if (entry == null || handler == null) return;
            Map<UUID, PlayerListEntry> map = findMap(handler);
            if (map != null) map.remove(idFor(name));
            Collection<PlayerListEntry> listed = findListed(handler);
            if (listed != null) listed.remove(entry);
        } catch (Throwable t) {
            SomethingIsWrongMod.LOGGER.warn("Nao foi possivel remover o jogador fantasma do Tab: {}", t.toString());
        }
    }

    public static void clear() {
        ACTIVE.clear(); // a lista pertence a conexao, que ja foi descartada
    }

    @SuppressWarnings("unchecked")
    private static Map<UUID, PlayerListEntry> findMap(ClientPlayNetworkHandler h) throws IllegalAccessException {
        for (Field f : ClientPlayNetworkHandler.class.getDeclaredFields()) {
            if (Map.class.isAssignableFrom(f.getType()) && f.getGenericType() instanceof ParameterizedType pt) {
                Type[] a = pt.getActualTypeArguments();
                if (a.length == 2 && a[0] == UUID.class && a[1] == PlayerListEntry.class) {
                    f.setAccessible(true);
                    return (Map<UUID, PlayerListEntry>) f.get(h);
                }
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static Collection<PlayerListEntry> findListed(ClientPlayNetworkHandler h) throws IllegalAccessException {
        for (Field f : ClientPlayNetworkHandler.class.getDeclaredFields()) {
            if (Collection.class.isAssignableFrom(f.getType()) && f.getGenericType() instanceof ParameterizedType pt) {
                Type[] a = pt.getActualTypeArguments();
                if (a.length == 1 && a[0] == PlayerListEntry.class) {
                    f.setAccessible(true);
                    return (Collection<PlayerListEntry>) f.get(h);
                }
            }
        }
        return null;
    }
}
