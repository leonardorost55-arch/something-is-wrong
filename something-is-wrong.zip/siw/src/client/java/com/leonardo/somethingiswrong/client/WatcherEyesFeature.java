package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.entity.WatcherEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.EyesFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;

/** Olhos palidos que brilham no escuro (renderizados sem iluminacao, como os olhos do Enderman). */
public class WatcherEyesFeature extends EyesFeatureRenderer<WatcherEntity, BipedEntityModel<WatcherEntity>> {
    private static final RenderLayer EYES = RenderLayer.getEyes(SomethingIsWrongMod.id("textures/entity/the_watcher_eyes.png"));

    public WatcherEyesFeature(FeatureRendererContext<WatcherEntity, BipedEntityModel<WatcherEntity>> context) {
        super(context);
    }

    @Override
    public RenderLayer getEyesTexture() {
        return EYES;
    }
}
