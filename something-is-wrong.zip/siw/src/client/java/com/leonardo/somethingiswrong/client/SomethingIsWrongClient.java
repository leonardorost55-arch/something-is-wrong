package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.entity.ModEntities;
import com.leonardo.somethingiswrong.net.EndingPayload;
import com.leonardo.somethingiswrong.net.InterferencePayload;
import com.leonardo.somethingiswrong.net.PhantomPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

/** Entrada do cliente: renderizador, interferencia visual (HUD) e tela de encerramento. */
public class SomethingIsWrongClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.THE_WATCHER, WatcherRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(InterferencePayload.ID,
                (payload, context) -> InterferenceHud.start(payload.durationTicks(), payload.intensity()));
        ClientPlayNetworking.registerGlobalReceiver(EndingPayload.ID,
                (payload, context) -> context.client().setScreen(new EndingScreen(payload.variant())));

        ClientPlayNetworking.registerGlobalReceiver(PhantomPayload.ID, (payload, context) -> {
            if (payload.add()) PhantomTab.add(context.client(), payload.name());
            else PhantomTab.remove(context.client(), payload.name());
        });

        HudRenderCallback.EVENT.register(InterferenceHud::render);
        ClientTickEvents.END_CLIENT_TICK.register(client -> InterferenceHud.tick(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            InterferenceHud.clear();
            PhantomTab.clear();
        });
    }
}
