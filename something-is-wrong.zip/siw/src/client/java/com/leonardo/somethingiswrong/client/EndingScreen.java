package com.leonardo.somethingiswrong.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Tela de encerramento. Pode ser fechada pelo botao ou com ESC; o jogador sempre recupera o controle. */
public class EndingScreen extends Screen {
    private int ticks = 0;
    private final String prefix;

    public EndingScreen(int variant) {
        super(Text.translatable(prefixFor(variant) + "title"));
        this.prefix = prefixFor(variant);
    }

    private static String prefixFor(int variant) {
        return switch (variant) {
            case 1 -> "screen.somethingiswrong.ending.v1.";
            case 2 -> "screen.somethingiswrong.ending.v2.";
            default -> "screen.somethingiswrong.ending.";
        };
    }

    @Override
    protected void init() {
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.somethingiswrong.ending.button"), b -> this.close())
                .dimensions(this.width / 2 - 75, this.height / 2 + 50, 150, 20).build());
    }

    @Override
    public void tick() {
        ticks++;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, this.width, this.height, 0xFF000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int fade = Math.min(255, ticks * 6);
        int gray = (fade << 24) | 0xC8CFD6;
        int dim = (Math.min(255, Math.max(0, (ticks - 30) * 6)) << 24) | 0x7A8590;
        int red = (Math.min(255, Math.max(0, (ticks - 60) * 4)) << 24) | 0x6E1C1C;
        int cx = this.width / 2;
        int cy = this.height / 2;
        if (fade > 4) ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, cy - 40, gray);
        if (ticks > 34) ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable(prefix + "line1"), cx, cy - 15, dim);
        if (ticks > 64) ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable(prefix + "line2"), cx, cy, red);
        if (ticks > 100) ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("screen.somethingiswrong.ending.hint"), cx, cy + 25, dim);
    }
}
