package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.DonateLink;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmLinkScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.function.DoubleConsumer;

/** Tela de configuracao (abre pelo Mod Menu). Salva em config/somethingiswrong.json ao fechar. */
public class SiwConfigScreen extends Screen {
    private final Screen parent;

    public SiwConfigScreen(Screen parent) {
        super(Text.translatable("config.somethingiswrong.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModSettings cfg = ConfigManager.get();
        int colW = 150;
        int gap = 10;
        int x1 = this.width / 2 - colW - gap / 2;
        int x2 = this.width / 2 + gap / 2;
        int row = Math.max(20, Math.min(24, (this.height - 100) / 6));
        int bh = Math.min(20, row - 2);
        int y = 34;

        this.addDrawableChild(new ValueSlider(x1, y, colW, bh, "config.somethingiswrong.intensity", 0, 100, cfg.intensity, true,
                v -> cfg.intensity = (int) Math.round(v)));
        this.addDrawableChild(new ValueSlider(x2, y, colW, bh, "config.somethingiswrong.frequency", 0.1, 3.0, cfg.eventFrequency, false,
                v -> cfg.eventFrequency = Math.round(v * 10.0) / 10.0));
        y += row;

        this.addDrawableChild(CyclingButtonWidget.<String>builder(v -> Text.translatable("config.somethingiswrong.narration." + v))
                .values("pt", "en", "off").initially(cfg.narrationLanguage)
                .build(x1, y, colW, bh, Text.translatable("config.somethingiswrong.narration"), (b, v) -> cfg.narrationLanguage = v));
        TreeSet<Integer> lengths = new TreeSet<>(List.of(20, 60, 120, 300, 600));
        lengths.add(cfg.campaignMinutes);
        this.addDrawableChild(CyclingButtonWidget.<Integer>builder(SiwConfigScreen::lengthText)
                .values(new ArrayList<>(lengths)).initially(cfg.campaignMinutes)
                .build(x2, y, colW, bh, Text.translatable("config.somethingiswrong.length"), (b, v) -> cfg.campaignMinutes = v));
        y += row;

        toggle(x1, y, colW, bh, "subtitles", cfg.narrationText, v -> cfg.narrationText = v);
        toggle(x2, y, colW, bh, "chat", cfg.chatResponses, v -> cfg.chatResponses = v);
        y += row;
        toggle(x1, y, colW, bh, "visual", cfg.visualInterference, v -> cfg.visualInterference = v);
        toggle(x2, y, colW, bh, "sounds", cfg.customSounds, v -> cfg.customSounds = v);
        y += row;
        toggle(x1, y, colW, bh, "phantom", cfg.phantomPlayer, v -> cfg.phantomPlayer = v);
        toggle(x2, y, colW, bh, "epilogue", cfg.epilogue, v -> cfg.epilogue = v);
        y += row;
        toggle(x1, y, colW, bh, "enabled", cfg.enabled, v -> cfg.enabled = v);

        int bottom = this.height - 28;
        if (DonateLink.isSet()) {
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("config.somethingiswrong.donate"), b -> openDonate())
                    .dimensions(x2, y, colW / 2 + 40, bh).build());
            int copyY = y + row;
            this.addDrawableChild(ButtonWidget.builder(Text.translatable("config.somethingiswrong.donate.copy"), b -> {
                this.client.keyboard.setClipboard(DonateLink.URL);
                b.setMessage(Text.translatable("config.somethingiswrong.donate.copied"));
            }).dimensions(x2, Math.min(copyY, bottom - row), colW / 2 + 40, bh).build());
        }
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("config.somethingiswrong.done"), b -> this.close())
                .dimensions(this.width / 2 - 100, bottom, 200, 20).build());
    }

    private void toggle(int x, int y, int w, int h, String key, boolean initial, java.util.function.Consumer<Boolean> set) {
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(initial)
                .build(x, y, w, h, Text.translatable("config.somethingiswrong." + key), (b, v) -> set.accept(v)));
    }

    private static Text lengthText(Integer minutes) {
        if (minutes < 60) return Text.literal(minutes + " min");
        double h = minutes / 60.0;
        return Text.literal((h == Math.floor(h) ? String.valueOf((int) h) : String.format("%.1f", h)) + " h");
    }

    private void openDonate() {
        this.client.setScreen(new ConfirmLinkScreen(confirmed -> {
            if (confirmed) Util.getOperatingSystem().open(URI.create(DonateLink.URL));
            this.client.setScreen(this);
        }, DonateLink.URL, true));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 14, 0xFFC8CFD6);
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.translatable("config.somethingiswrong.hint"),
                this.width / 2, this.height - 42, 0xFF7A8590);
    }

    @Override
    public void close() {
        ModSettings cfg = ConfigManager.get();
        cfg.sanitize();
        ConfigManager.save();
        this.client.setScreen(this.parent);
    }

    /** Barra deslizante simples (inteira ou decimal). */
    private static final class ValueSlider extends SliderWidget {
        private final String labelKey;
        private final double min;
        private final double max;
        private final boolean integer;
        private final DoubleConsumer onChange;

        ValueSlider(int x, int y, int w, int h, String labelKey, double min, double max, double current, boolean integer, DoubleConsumer onChange) {
            super(x, y, w, h, Text.empty(), (Math.max(min, Math.min(max, current)) - min) / (max - min));
            this.labelKey = labelKey;
            this.min = min;
            this.max = max;
            this.integer = integer;
            this.onChange = onChange;
            this.updateMessage();
        }

        private double current() {
            return min + this.value * (max - min);
        }

        @Override
        protected void updateMessage() {
            double v = current();
            String shown = integer ? String.valueOf((int) Math.round(v)) : String.format("%.1fx", Math.round(v * 10.0) / 10.0);
            this.setMessage(Text.translatable(labelKey).append(": " + shown));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
