package com.leonardo.somethingiswrong.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Integracao opcional com o Mod Menu: so e carregada se o Mod Menu estiver instalado. */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return SiwConfigScreen::new;
    }
}
