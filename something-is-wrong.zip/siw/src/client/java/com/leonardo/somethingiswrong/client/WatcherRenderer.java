package com.leonardo.somethingiswrong.client;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.entity.WatcherEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Modelo humanoide vanilla (camada do Zombie) com textura propria e proporcao levemente alongada. */
public class WatcherRenderer extends MobEntityRenderer<WatcherEntity, BipedEntityModel<WatcherEntity>> {
    private static final Identifier TEXTURE = SomethingIsWrongMod.id("textures/entity/the_watcher.png");

    public WatcherRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new BipedEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.0f);
        this.addFeature(new WatcherEyesFeature(this));
    }

    @Override
    public Identifier getTexture(WatcherEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(WatcherEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(0.95f, 1.12f, 0.95f);
    }
}
