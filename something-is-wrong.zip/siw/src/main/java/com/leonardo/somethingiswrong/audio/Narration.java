package com.leonardo.somethingiswrong.audio;

import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.server.SpawnFinder;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

/**
 * Narracao: voz sussurrada (idioma escolhido em narrationLanguage: pt/en/off) tocada logo atras do jogador,
 * mais o texto na barra de acao (idioma do jogo) como legenda. Ambos desligaveis na configuracao.
 */
public final class Narration {
    private Narration() {}

    public static void say(ServerPlayerEntity p, String key) {
        say(p, key, true);
    }

    public static void say(ServerPlayerEntity p, String key, boolean withText) {
        ModSettings cfg = ConfigManager.get();
        if (withText && cfg.narrationText) {
            p.sendMessage(Text.translatable("narration.somethingiswrong." + key).formatted(Formatting.GRAY, Formatting.ITALIC), true);
        }
        if (cfg.narrationVoiceEnabled()) {
            SoundEvent s = ModSounds.narration(cfg.narrationLanguage, key);
            if (s != null) {
                Vec3d pos = p.getPos().add(SpawnFinder.dir(p, Math.PI).multiply(1.3)).add(0, 1.4, 0);
                Audio.voice(p, s, pos, 1.0f, 1.0f);
            }
        }
    }
}
