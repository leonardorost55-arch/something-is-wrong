package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.anomaly.SafetyContext;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Converte o estado do jogador no SafetyContext puro usado pelo agendador. */
public final class ContextBuilder {
    private ContextBuilder() {}

    public static SafetyContext build(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        boolean hostile = !w.getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(12.0),
                e -> e.isAlive() && e.getTarget() == p).isEmpty();
        boolean combat = p.getLastAttackedTime() > 0 && (p.age - p.getLastAttackedTime()) < 200;
        boolean falling = p.fallDistance > 3.0f || (!p.isOnGround() && !p.isTouchingWater() && p.getVelocity().y < -0.6);
        return new SafetyContext(
                p.isSpectator(),
                combat,
                hostile,
                p.getHealth() < 8.0f,
                p.isTouchingWater() || p.isInLava(),
                p.isOnFire(),
                falling,
                !w.isSkyVisible(p.getBlockPos()),
                WatcherManager.isPresent());
    }
}
