package com.leonardo.somethingiswrong.campaign;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Estado persistente da campanha. Serializa para Map generico (String/Integer/Long/Boolean/Map)
 * e e convertido para NBT pela camada de persistencia. Sem dependencias do Minecraft.
 */
public final class CampaignState {
    public static final int SCHEMA = 1;

    public String campaignId = "";
    public boolean started = false;
    public long elapsedTicks = 0;
    public Phase phase = Phase.NORMALITY;
    public final Map<String, ExecutionRecord> executed = new LinkedHashMap<>();
    public String lastEventId = "";
    public long lastEventTick = -1;
    /** Tick da campanha da ultima anomalia de qualquer tipo (-1 = nenhuma). */
    public long lastAnyEventTick = -1;
    public String watcherUuid = "";
    public ClimaxStatus climax = ClimaxStatus.NOT_STARTED;
    public long climaxTicks = 0;
    /** Bitmask dos fragmentos de lore ja ouvidos (bit 0..7). */
    public int loreMask = 0;
    /** Quantas vezes o jogador fez o Watcher sumir ao olhar para ele. */
    public int watcherLooks = 0;
    /** Medo acumulado (0..100). Sistema invisivel: so ajusta a frequencia dos eventos. */
    public int fear = 0;
    /** Quantas vezes o Watcher respondeu a mensagens do jogador no chat. */
    public int chatReplies = 0;

    public void start() {
        started = true;
        campaignId = UUID.randomUUID().toString();
    }

    /** Reinicia a campanha. Nao toca em nada alem deste estado (o mundo nao e afetado). */
    public void reset() {
        campaignId = "";
        started = false;
        elapsedTicks = 0;
        phase = Phase.NORMALITY;
        executed.clear();
        lastEventId = "";
        lastEventTick = -1;
        lastAnyEventTick = -1;
        watcherUuid = "";
        climax = ClimaxStatus.NOT_STARTED;
        climaxTicks = 0;
        loreMask = 0;
        watcherLooks = 0;
        fear = 0;
        chatReplies = 0;
    }

    public int countOf(String id) {
        ExecutionRecord r = executed.get(id);
        return r == null ? 0 : r.count;
    }

    public long lastTickOf(String id) {
        ExecutionRecord r = executed.get(id);
        return r == null ? -1 : r.lastTick;
    }

    /** Torna o estado coerente apos carregar dados possivelmente invalidos. */
    public void validate(int campaignMinutes) {
        if (elapsedTicks < 0) elapsedTicks = 0;
        if (climaxTicks < 0) climaxTicks = 0;
        loreMask &= 0xFF;
        if (watcherLooks < 0) watcherLooks = 0;
        fear = Math.max(0, Math.min(100, fear));
        if (chatReplies < 0) chatReplies = 0;
        if (campaignId == null) campaignId = "";
        if (watcherUuid == null) watcherUuid = "";
        if (lastEventId == null) lastEventId = "";
        if (climax == null) climax = ClimaxStatus.NOT_STARTED;
        if (!started && (elapsedTicks > 0 || climax != ClimaxStatus.NOT_STARTED || !executed.isEmpty())) {
            // dados de uma campanha em andamento sem a flag: considerar iniciada
            started = true;
        }
        if (started && campaignId.isEmpty()) campaignId = UUID.randomUUID().toString();
        if (climax == ClimaxStatus.NOT_STARTED) climaxTicks = 0;
        if (climax == ClimaxStatus.RUNNING && climaxTicks > ClimaxTimeline.END_TICK) climax = ClimaxStatus.FINISHED;
        executed.values().removeIf(r -> r == null || r.count <= 0);
        phase = Phase.atBaseSeconds(Phase.baseSeconds(elapsedTicks, campaignMinutes));
        if (climax != ClimaxStatus.NOT_STARTED) phase = Phase.CLIMAX;
    }

    // ---------- serializacao ----------

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("schema", SCHEMA);
        m.put("campaignId", campaignId);
        m.put("started", started);
        m.put("elapsedTicks", elapsedTicks);
        m.put("phase", phase.ordinal());
        m.put("lastEventId", lastEventId);
        m.put("lastEventTick", lastEventTick);
        m.put("lastAnyEventTick", lastAnyEventTick);
        m.put("watcherUuid", watcherUuid);
        m.put("climax", climax.name());
        m.put("climaxTicks", climaxTicks);
        m.put("loreMask", loreMask);
        m.put("watcherLooks", watcherLooks);
        m.put("fear", fear);
        m.put("chatReplies", chatReplies);
        Map<String, Object> ex = new LinkedHashMap<>();
        for (Map.Entry<String, ExecutionRecord> e : executed.entrySet()) {
            Map<String, Object> r = new HashMap<>();
            r.put("count", e.getValue().count);
            r.put("lastTick", e.getValue().lastTick);
            ex.put(e.getKey(), r);
        }
        m.put("executed", ex);
        return m;
    }

    /** Leitura tolerante: chaves ausentes ou de tipo errado recebem valores padrao. */
    public static CampaignState fromMap(Map<String, Object> m) {
        CampaignState s = new CampaignState();
        if (m == null) return s;
        s.campaignId = str(m.get("campaignId"), "");
        s.started = bool(m.get("started"), false);
        s.elapsedTicks = num(m.get("elapsedTicks"), 0);
        s.phase = Phase.fromOrdinal((int) num(m.get("phase"), 0));
        s.lastEventId = str(m.get("lastEventId"), "");
        s.lastEventTick = num(m.get("lastEventTick"), -1);
        s.lastAnyEventTick = num(m.get("lastAnyEventTick"), -1);
        s.watcherUuid = str(m.get("watcherUuid"), "");
        s.climax = ClimaxStatus.parse(str(m.get("climax"), ""));
        s.climaxTicks = num(m.get("climaxTicks"), 0);
        s.loreMask = (int) num(m.get("loreMask"), 0);
        s.watcherLooks = (int) num(m.get("watcherLooks"), 0);
        s.fear = (int) num(m.get("fear"), 0);
        s.chatReplies = (int) num(m.get("chatReplies"), 0);
        Object ex = m.get("executed");
        if (ex instanceof Map<?, ?> em) {
            for (Map.Entry<?, ?> e : em.entrySet()) {
                if (e.getKey() instanceof String k && e.getValue() instanceof Map<?, ?> rm) {
                    int c = (int) num(rm.get("count"), 0);
                    long t = num(rm.get("lastTick"), -1);
                    if (c > 0) s.executed.put(k, new ExecutionRecord(c, t));
                }
            }
        }
        return s;
    }

    private static String str(Object o, String d) { return o instanceof String s ? s : d; }
    private static boolean bool(Object o, boolean d) {
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.intValue() != 0;
        return d;
    }
    private static long num(Object o, long d) { return o instanceof Number n ? n.longValue() : d; }
}
