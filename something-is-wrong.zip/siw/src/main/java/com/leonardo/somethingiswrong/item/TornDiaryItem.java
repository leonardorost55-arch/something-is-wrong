package com.leonardo.somethingiswrong.item;

import com.leonardo.somethingiswrong.campaign.LoreSchedule;
import com.leonardo.somethingiswrong.server.CampaignManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Diario Rasgado: ao usar, mostra no chat os fragmentos do diario que voce ja ouviu. */
public class TornDiaryItem extends Item {
    public TornDiaryItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            int mask = CampaignManager.state().loreMask;
            boolean any = false;
            for (int i = 0; i <= LoreSchedule.FINAL_FRAGMENT; i++) {
                if ((mask & (1 << i)) != 0) {
                    any = true;
                    sp.sendMessage(Text.translatable("narration.somethingiswrong." + LoreSchedule.key(i))
                            .formatted(Formatting.GRAY, Formatting.ITALIC), false);
                }
            }
            if (!any) {
                sp.sendMessage(Text.translatable("item.somethingiswrong.torn_diary.empty")
                        .formatted(Formatting.GRAY, Formatting.ITALIC), true);
            }
            sp.getItemCooldownManager().set(this, 40);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
