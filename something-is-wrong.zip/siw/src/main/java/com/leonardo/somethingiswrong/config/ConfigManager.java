package com.leonardo.somethingiswrong.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Le/grava config/somethingiswrong.json. Regras:
 * - arquivo ausente: cria com os padroes;
 * - arquivo invalido: usa padroes em memoria e NAO sobrescreve o arquivo do usuario;
 * - valores fora de faixa: corrigidos apenas em memoria (o arquivo nao e reescrito).
 */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static volatile ModSettings current = new ModSettings();

    private ConfigManager() {}

    public static ModSettings get() { return current; }

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("somethingiswrong.json");
    }

    public static synchronized void load() {
        Path p = path();
        ModSettings loaded = null;
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                loaded = GSON.fromJson(r, ModSettings.class);
            } catch (Exception e) {
                SomethingIsWrongMod.LOGGER.warn("Config invalida ({}); usando padroes sem sobrescrever o arquivo.", e.toString());
            }
        } else {
            current = new ModSettings();
            save();
            return;
        }
        if (loaded == null) loaded = new ModSettings();
        for (String w : loaded.sanitize()) SomethingIsWrongMod.LOGGER.warn("Config: {}", w);
        current = loaded;
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(path().getParent());
            try (Writer w = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
                GSON.toJson(current, w);
            }
        } catch (IOException e) {
            SomethingIsWrongMod.LOGGER.warn("Nao foi possivel gravar a config: {}", e.toString());
        }
    }
}
