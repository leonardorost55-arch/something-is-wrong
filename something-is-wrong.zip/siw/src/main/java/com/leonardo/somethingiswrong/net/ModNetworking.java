package com.leonardo.somethingiswrong.net;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public final class ModNetworking {
    private ModNetworking() {}

    public static void registerPayloads() {
        PayloadTypeRegistry.playS2C().register(InterferencePayload.ID, InterferencePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(EndingPayload.ID, EndingPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PhantomPayload.ID, PhantomPayload.CODEC);
    }

    public static void sendInterference(ServerPlayerEntity p, int durationTicks, int intensity) {
        if (ServerPlayNetworking.canSend(p, InterferencePayload.ID)) {
            ServerPlayNetworking.send(p, new InterferencePayload(Math.max(1, Math.min(durationTicks, 200)),
                    Math.max(0, Math.min(intensity, 100))));
        }
    }

    public static void sendPhantom(ServerPlayerEntity p, String name, boolean add) {
        if (ServerPlayNetworking.canSend(p, PhantomPayload.ID)) {
            ServerPlayNetworking.send(p, new PhantomPayload(name, add));
        }
    }

    public static void sendEnding(ServerPlayerEntity p, int variant) {
        if (ServerPlayNetworking.canSend(p, EndingPayload.ID)) {
            ServerPlayNetworking.send(p, new EndingPayload(variant));
        }
    }
}
