package com.leonardo.somethingiswrong.debug;

import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.campaign.CampaignClock;
import com.leonardo.somethingiswrong.campaign.CampaignState;
import com.leonardo.somethingiswrong.campaign.ExecutionRecord;
import com.leonardo.somethingiswrong.campaign.Phase;
import com.leonardo.somethingiswrong.campaign.WatcherEvolution;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.server.CampaignManager;
import com.leonardo.somethingiswrong.server.SpawnFinder;
import com.leonardo.somethingiswrong.server.WatcherManager;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.function.Consumer;

/**
 * /somethingiswrong ...
 * - Ferramentas de teste: operador (nivel 2). Comandos destrutivos exigem confirmacao explicita e nunca tocam no mundo.
 * - /somethingiswrong config ...: operador, ou o dono do mundo em single player (sem precisar ligar cheats).
 */
public final class DebugCommands {
    private static final Random RANDOM = new Random();

    private DebugCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(build()));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> dev(String name) {
        return CommandManager.literal(name).requires(s -> s.hasPermissionLevel(2));
    }

    private static boolean canConfig(ServerCommandSource s) {
        return s.hasPermissionLevel(2) || (s.getServer().isSingleplayer() && s.getServer().getCurrentPlayerCount() <= 1);
    }

    private static LiteralArgumentBuilder<ServerCommandSource> build() {
        return CommandManager.literal("somethingiswrong")
                .then(dev("status").executes(DebugCommands::status))
                .then(dev("time").executes(DebugCommands::time))
                .then(dev("start").executes(c -> {
                    boolean ok = CampaignManager.startCampaign();
                    return say(c, ok ? "Campanha iniciada." : "Campanha ja iniciada (ou mundo ainda nao carregado).");
                }))
                .then(dev("phase").then(CommandManager.literal("next").executes(c -> {
                    CampaignManager.nextPhase();
                    return say(c, "Fase atual: " + CampaignManager.state().phase.name());
                })))
                .then(dev("trigger").then(CommandManager.argument("id", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(AnomalyRegistry.ids(), b))
                        .executes(DebugCommands::trigger)))
                .then(dev("watcher")
                        .then(CommandManager.literal("spawn").executes(DebugCommands::watcherSpawn))
                        .then(CommandManager.literal("remove").executes(c -> {
                            int n = WatcherManager.discardAll(c.getSource().getServer());
                            return say(c, "Watchers removidos: " + n);
                        })))
                .then(dev("climax").then(CommandManager.literal("start").executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayer();
                    if (p == null) return say(c, "Execute como jogador.");
                    boolean ok = CampaignManager.forceFinale(p);
                    return say(c, ok ? "Final iniciado (dura ~25 s, termina sozinho)." : "O final ja foi iniciado ou concluido nesta campanha.");
                })))
                .then(dev("events").executes(DebugCommands::events))
                .then(dev("reset").then(CommandManager.literal("confirm").executes(c -> {
                    CampaignManager.resetCampaign();
                    return say(c, "Estado da campanha reiniciado. O mundo nao foi alterado.");
                })))
                .then(dev("reload").executes(c -> {
                    ConfigManager.load();
                    return say(c, "Configuracao recarregada.");
                }))
                .then(configTree());
    }

    // ---------- /somethingiswrong config ----------

    private static LiteralArgumentBuilder<ServerCommandSource> configTree() {
        return CommandManager.literal("config").requires(DebugCommands::canConfig)
                .then(CommandManager.literal("show").executes(DebugCommands::showConfig))
                .then(CommandManager.literal("intensity").then(CommandManager.argument("value", IntegerArgumentType.integer(0, 100))
                        .executes(c -> set(c, s -> s.intensity = IntegerArgumentType.getInteger(c, "value"), "intensity"))))
                .then(CommandManager.literal("frequency").then(CommandManager.argument("value", DoubleArgumentType.doubleArg(0.1, 3.0))
                        .executes(c -> set(c, s -> s.eventFrequency = DoubleArgumentType.getDouble(c, "value"), "frequency"))))
                .then(CommandManager.literal("narration").then(CommandManager.argument("lang", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(java.util.List.of("pt", "en", "off"), b))
                        .executes(c -> set(c, s -> s.narrationLanguage = StringArgumentType.getString(c, "lang"), "narration"))))
                .then(CommandManager.literal("subtitles").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.narrationText = BoolArgumentType.getBool(c, "on"), "subtitles"))))
                .then(CommandManager.literal("visual").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.visualInterference = BoolArgumentType.getBool(c, "on"), "visual"))))
                .then(CommandManager.literal("sounds").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.customSounds = BoolArgumentType.getBool(c, "on"), "sounds"))))
                .then(CommandManager.literal("chat").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.chatResponses = BoolArgumentType.getBool(c, "on"), "chat"))))
                .then(CommandManager.literal("phantom").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.phantomPlayer = BoolArgumentType.getBool(c, "on"), "phantom"))))
                .then(CommandManager.literal("epilogue").then(CommandManager.argument("on", BoolArgumentType.bool())
                        .executes(c -> set(c, s -> s.epilogue = BoolArgumentType.getBool(c, "on"), "epilogue"))))
                .then(CommandManager.literal("length").then(CommandManager.argument("minutes", IntegerArgumentType.integer(3, 720))
                        .executes(c -> set(c, s -> s.campaignMinutes = IntegerArgumentType.getInteger(c, "minutes"), "length (min)"))));
    }

    private static int set(CommandContext<ServerCommandSource> c, Consumer<ModSettings> change, String what) {
        ModSettings cfg = ConfigManager.get();
        change.accept(cfg);
        cfg.sanitize();
        ConfigManager.save();
        return say(c, "Configuracao salva (" + what + "). Use /somethingiswrong config show para ver tudo.");
    }

    private static int showConfig(CommandContext<ServerCommandSource> c) {
        ModSettings s = ConfigManager.get();
        say(c, "intensity=" + s.intensity + " | frequency=" + s.eventFrequency + " | campaignMinutes=" + s.campaignMinutes);
        say(c, "narration=" + s.narrationLanguage + " | subtitles=" + s.narrationText + " | chat=" + s.chatResponses);
        say(c, "visual=" + s.visualInterference + " | sounds=" + s.customSounds + " | phantom=" + s.phantomPlayer + " | epilogue=" + s.epilogue);
        say(c, "blockedDimensions=" + s.blockedDimensions);
        return 1;
    }

    // ---------- utilitarios ----------

    private static int say(CommandContext<ServerCommandSource> c, String msg) {
        c.getSource().sendFeedback(() -> Text.literal(msg), false);
        return 1;
    }

    private static String mmss(long ticks) {
        long s = ticks / 20;
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private static int status(CommandContext<ServerCommandSource> c) {
        CampaignState st = CampaignManager.state();
        ModSettings cfg = ConfigManager.get();
        say(c, "Campanha: " + (st.started ? st.campaignId : "(nao iniciada)") + " | mod " + (cfg.enabled ? "ativo" : "DESATIVADO"));
        say(c, "Fase: " + st.phase.name() + " | final: " + st.climax.name() + " (" + st.climaxTicks + " ticks)");
        say(c, "Ultimo evento: " + (st.lastEventId.isEmpty() ? "-" : st.lastEventId + " @" + mmss(st.lastEventTick)));
        say(c, "Watcher ativo: " + WatcherManager.isPresent() + " | fase evolutiva: " + WatcherEvolution.stage(st)
                + " | medo: " + st.fear + " | olhadas: " + st.watcherLooks + " | respostas no chat: " + st.chatReplies);
        return 1;
    }

    private static int time(CommandContext<ServerCommandSource> c) {
        CampaignState st = CampaignManager.state();
        ModSettings cfg = ConfigManager.get();
        double base = CampaignClock.baseSeconds(st, cfg);
        return say(c, "Tempo acumulado: " + mmss(st.elapsedTicks) + " (" + st.elapsedTicks + " ticks) | escala base: "
                + mmss((long) (base * 20)) + " / " + mmss(Phase.FINALE_BASE_SECONDS * 20L)
                + " | duracao configurada: " + cfg.campaignMinutes + " min");
    }

    private static int trigger(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity p = c.getSource().getPlayer();
        if (p == null) return say(c, "Execute como jogador.");
        String id = StringArgumentType.getString(c, "id");
        if (AnomalyRegistry.get(id) == null) return say(c, "Anomalia desconhecida: " + id);
        boolean ok = CampaignManager.forceTrigger(id, p);
        return say(c, ok ? "Executada: " + id : "Nao foi possivel executar agora: " + id);
    }

    private static int watcherSpawn(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity p = c.getSource().getPlayer();
        if (p == null) return say(c, "Execute como jogador.");
        Optional<Vec3d> pos = SpawnFinder.find(p.getServerWorld(), p, SpawnFinder.Placement.FRONT, 10, 14, false, RANDOM);
        if (pos.isEmpty()) pos = SpawnFinder.find(p.getServerWorld(), p, SpawnFinder.Placement.ANY, 8, 14, false, RANDOM);
        if (pos.isEmpty()) return say(c, "Sem posicao valida por perto.");
        boolean ok = WatcherManager.spawn(p.getServerWorld(), p, pos.get(),
                new WatcherManager.Session(p.getUuid(), 400, 10, true, false));
        return say(c, ok ? "Watcher invocado (some quando voce olhar ou apos 20 s)." : "Ja existe um Watcher ativo.");
    }

    private static int events(CommandContext<ServerCommandSource> c) {
        CampaignState st = CampaignManager.state();
        say(c, "Execucoes registradas:");
        for (Map.Entry<String, ExecutionRecord> e : st.executed.entrySet()) {
            say(c, " - " + e.getKey() + ": " + e.getValue().count + "x, ultima @" + mmss(e.getValue().lastTick));
        }
        say(c, "Ultimas entradas do log:");
        var log = CampaignManager.recentLog();
        int from = Math.max(0, log.size() - 10);
        for (int i = from; i < log.size(); i++) say(c, " " + log.get(i));
        return 1;
    }
}
