package com.leonardo.somethingiswrong.campaign;

/**
 * "Sanidade" invisivel: o medo sobe com o que o jogador presencia e cai devagar com o tempo.
 * Nao ha barra nem punicao: so muda a chance dos eventos (0.85x a 1.45x). O Amuleto do Silencio reduz ganhos e acelera a queda.
 */
public final class FearModel {
    public static final int MAX = 100;
    public static final int GAIN_ANOMALY = 3;
    public static final int GAIN_WATCHER_SEEN = 5;
    public static final int GAIN_CHAT = 2;
    public static final long DECAY_INTERVAL = 400;
    public static final long DECAY_INTERVAL_CHARM = 200;

    private FearModel() {}

    public static void add(CampaignState s, int amount, boolean charm) {
        int a = charm ? Math.max(1, amount / 2) : amount;
        s.fear = Math.max(0, Math.min(MAX, s.fear + a));
    }

    /** Chamar a cada tick da campanha. */
    public static void tick(CampaignState s, boolean charm) {
        long interval = charm ? DECAY_INTERVAL_CHARM : DECAY_INTERVAL;
        if (s.elapsedTicks > 0 && s.elapsedTicks % interval == 0 && s.fear > 0) s.fear--;
    }

    public static double chanceMultiplier(int fear) {
        int f = Math.max(0, Math.min(MAX, fear));
        return 0.85 + 0.60 * f / MAX;
    }
}
