package com.leonardo.somethingiswrong.campaign;

import java.util.List;

/** Ids das conquistas (advancements em data/somethingiswrong/advancement/<id>.json). */
public final class AchievementIds {
    public static final String ROOT = "root";
    public static final String FIRST_SIGN = "first_sign";
    public static final String ECHO = "echo";
    public static final String DIARY_START = "diary_start";
    public static final String DIARY_FULL = "diary_full";
    public static final String DONT_BLINK = "dont_blink";
    public static final String KEEP_LOOKING = "keep_looking";
    public static final String TOO_DEEP = "too_deep";
    public static final String WHY_STOP = "why_stop";
    public static final String INSOMNIA = "insomnia";
    public static final String THE_WATCHER = "the_watcher";
    public static final String I_SAW_YOU = "i_saw_you";
    public static final String NEVER_ALONE = "never_alone";
    public static final String IGNORED = "ignored";
    public static final String ZOOM = "zoom";
    public static final String ANSWERED = "answered";
    public static final String SECRET_CODE = "secret_code";
    public static final String CONVERSED = "conversed";

    public static final List<String> ALL = List.of(ROOT, FIRST_SIGN, ECHO, DIARY_START, DIARY_FULL, DONT_BLINK,
            KEEP_LOOKING, TOO_DEEP, WHY_STOP, INSOMNIA, THE_WATCHER, I_SAW_YOU, NEVER_ALONE, IGNORED, ZOOM, ANSWERED, SECRET_CODE, CONVERSED);

    private AchievementIds() {}
}
