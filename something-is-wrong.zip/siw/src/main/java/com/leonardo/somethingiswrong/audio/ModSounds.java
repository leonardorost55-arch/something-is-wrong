package com.leonardo.somethingiswrong.audio;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Sons originais (arquivos .ogg em assets/somethingiswrong/sounds, definidos em sounds.json). */
public final class ModSounds {
    public static final SoundEvent DRONE = make("ambient.drone");
    public static final SoundEvent WHISPER = make("ambient.whisper");
    public static final SoundEvent BREATH = make("ambient.breath");
    public static final SoundEvent CREAK = make("ambient.creak");
    public static final SoundEvent WATCHER_AMBIENT = make("watcher.ambient");
    public static final SoundEvent WATCHER_VANISH = make("watcher.vanish");
    public static final SoundEvent STATIC = make("ambient.static");
    public static final SoundEvent HEARTBEAT = make("ambient.heartbeat");
    public static final SoundEvent KNOCK = make("ambient.knock");
    public static final SoundEvent MUSIC_BOX = make("ambient.music_box");

    /** Chaves das falas narradas (arquivos narration/<lang>/<chave>.ogg). */
    public static final String[] NARRATION_KEYS = {"lore_1", "lore_2", "lore_3", "lore_4", "lore_5", "lore_6", "lore_7", "lore_8",
            "r_still", "r_under", "r_look", "r_walk", "r_sleep", "r_close", "r_final",
            "c_who", "c_help", "c_hello", "c_leave", "c_secret", "r_zoom"};
    private static final Map<String, SoundEvent> NARRATION = new HashMap<>();

    static {
        for (String lang : new String[]{"pt", "en"}) {
            for (String k : NARRATION_KEYS) {
                NARRATION.put(lang + "." + k, make("narration." + lang + "." + k));
            }
        }
    }

    public static SoundEvent narration(String lang, String key) {
        return NARRATION.get(lang + "." + key);
    }

    private ModSounds() {}

    private static SoundEvent make(String name) {
        Identifier id = SomethingIsWrongMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Forca o carregamento da classe (e, portanto, o registro) durante a inicializacao. */
    public static void register() {}
}
