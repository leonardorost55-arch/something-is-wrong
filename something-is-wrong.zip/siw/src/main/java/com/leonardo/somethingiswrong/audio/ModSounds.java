package com.leonardo.somethingiswrong.audio;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Sons originais (arquivos .ogg em assets/somethingiswrong/sounds, definidos em sounds.json). */
public final class ModSounds {
    public static final SoundEvent DRONE = make("ambient.drone");
    public static final SoundEvent WHISPER = make("ambient.whisper");
    public static final SoundEvent BREATH = make("ambient.breath");
    public static final SoundEvent CREAK = make("ambient.creak");
    public static final SoundEvent WATCHER_AMBIENT = make("watcher.ambient");
    public static final SoundEvent WATCHER_VANISH = make("watcher.vanish");
    public static final SoundEvent STATIC = make("ambient.static");

    private ModSounds() {}

    private static SoundEvent make(String name) {
        Identifier id = SomethingIsWrongMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Forca o carregamento da classe (e, portanto, o registro) durante a inicializacao. */
    public static void register() {}
}
