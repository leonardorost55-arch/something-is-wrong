package com.leonardo.somethingiswrong;

/**
 * Link de apoio ao criador. Se ficar vazio, os botoes de apoio nao aparecem.
 * O link so e aberto quando o jogador clica, pela tela de confirmacao padrao do Minecraft.
 */
public final class DonateLink {
    public static final String URL = "";

    private DonateLink() {}

    public static boolean isSet() {
        return URL != null && URL.startsWith("https://");
    }
}
