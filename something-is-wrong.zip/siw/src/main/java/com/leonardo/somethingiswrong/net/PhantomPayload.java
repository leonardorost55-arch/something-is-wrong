package com.leonardo.somethingiswrong.net;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: mostra/remove o "jogador fantasma" na lista Tab (apenas visual, so no cliente alvo). */
public record PhantomPayload(String name, boolean add) implements CustomPayload {
    public static final CustomPayload.Id<PhantomPayload> ID = new CustomPayload.Id<>(SomethingIsWrongMod.id("phantom"));
    public static final PacketCodec<RegistryByteBuf, PhantomPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, PhantomPayload::name,
            PacketCodecs.BOOL, PhantomPayload::add,
            PhantomPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
