package com.leonardo.somethingiswrong.campaign;

/** Fases da campanha. Tempos em segundos "base" (campanha de 20 minutos). */
public enum Phase {
    NORMALITY(0), COINCIDENCES(180), SOMETHING_WRONG(360), PRESENCE(540), ENTITY(720), RUPTURE(900), CLIMAX(1080);

    public static final int FINALE_BASE_SECONDS = 1200;

    public final int startBaseSeconds;

    Phase(int s) { this.startBaseSeconds = s; }

    public static Phase atBaseSeconds(double baseSeconds) {
        Phase r = NORMALITY;
        for (Phase p : values()) {
            if (baseSeconds >= p.startBaseSeconds) r = p;
        }
        return r;
    }

    /** Converte ticks decorridos em segundos "base" considerando a duracao configurada. */
    public static double baseSeconds(long elapsedTicks, int campaignMinutes) {
        return (elapsedTicks / 20.0) * (20.0 / campaignMinutes);
    }

    /** Converte segundos base em ticks reais para a duracao configurada. */
    public static long ticksForBaseSeconds(double baseSeconds, int campaignMinutes) {
        return (long) Math.ceil(baseSeconds * (campaignMinutes / 20.0) * 20.0);
    }

    public static Phase fromOrdinal(int o) {
        Phase[] v = values();
        return (o >= 0 && o < v.length) ? v[o] : NORMALITY;
    }
}
