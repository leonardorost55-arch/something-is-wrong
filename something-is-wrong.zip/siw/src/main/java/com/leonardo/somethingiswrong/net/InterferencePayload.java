package com.leonardo.somethingiswrong.net;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: inicia interferencia visual (duracao em ticks, intensidade 0..100). */
public record InterferencePayload(int durationTicks, int intensity) implements CustomPayload {
    public static final CustomPayload.Id<InterferencePayload> ID =
            new CustomPayload.Id<>(SomethingIsWrongMod.id("interference"));
    public static final PacketCodec<RegistryByteBuf, InterferencePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, InterferencePayload::durationTicks,
            PacketCodecs.VAR_INT, InterferencePayload::intensity,
            InterferencePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
