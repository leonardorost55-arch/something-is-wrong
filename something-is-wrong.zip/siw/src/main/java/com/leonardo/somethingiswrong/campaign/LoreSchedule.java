package com.leonardo.somethingiswrong.campaign;

/**
 * Diario do Primeiro Jogador: 7 fragmentos ouvidos durante a campanha (lore_1..lore_7) e o 8o no final.
 * Os fragmentos sao sempre contados em ordem; cada um so pode surgir a partir de um tempo minimo.
 */
public final class LoreSchedule {
    public static final int DIARY_FRAGMENTS = 7;
    public static final int FINAL_FRAGMENT = 7; // indice 7 = lore_8
    public static final int ALL_MASK = 0xFF;
    /** Segundos "base" (campanha de 20 min) a partir dos quais cada fragmento pode aparecer. */
    private static final int[] START = {200, 300, 420, 540, 660, 810, 930};

    private LoreSchedule() {}

    /** Proximo fragmento do diario liberado para o tempo atual, ou -1. */
    public static int next(int mask, double baseSeconds) {
        for (int i = 0; i < DIARY_FRAGMENTS; i++) {
            if ((mask & (1 << i)) == 0) {
                return baseSeconds >= START[i] ? i : -1; // ordem estrita
            }
        }
        return -1;
    }

    public static int mark(int mask, int index) { return (mask | (1 << index)) & ALL_MASK; }

    public static int count(int mask) { return Integer.bitCount(mask & ALL_MASK); }

    /** Chave do audio/texto: indice 0 -> "lore_1". */
    public static String key(int index) { return "lore_" + (index + 1); }
}
