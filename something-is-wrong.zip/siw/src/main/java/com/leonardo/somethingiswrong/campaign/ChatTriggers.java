package com.leonardo.somethingiswrong.campaign;

import java.text.Normalizer;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Frases (PT/EN) que o Watcher "escuta" no chat. Retorna a chave da fala, ou null. */
public final class ChatTriggers {
    public static final String WHO = "c_who";
    public static final String HELP = "c_help";
    public static final String HELLO = "c_hello";
    public static final String LEAVE = "c_leave";
    public static final String SECRET = "c_secret";

    private static final Map<String, String[]> WORDS = new LinkedHashMap<>();

    static {
        // ordem importa: o codigo secreto vence as demais
        WORDS.put(SECRET, new String[]{"something is wrong", "algo esta errado", "algo ta errado"});
        WORDS.put(WHO, new String[]{"quem e voce", "quem voce e", "quem ta ai", "quem esta ai", "who are you", "who is there", "who's there", "watcher"});
        WORDS.put(HELP, new String[]{"socorro", "ajuda", "me ajude", "help", "help me"});
        WORDS.put(LEAVE, new String[]{"vou embora", "quero sair", "vou sair", "i want to leave", "let me out", "im leaving", "i am leaving", "leave me alone", "me deixa em paz"});
        WORDS.put(HELLO, new String[]{"ola", "oi", "oie", "hello", "hi", "hey", "alguem ai", "anyone there", "anybody there"});
    }

    private ChatTriggers() {}

    public static String normalize(String text) {
        if (text == null) return "";
        String n = Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        n = n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9' ]+", " ").replaceAll("\\s+", " ").trim();
        return n;
    }

    public static String match(String text) {
        String n = " " + normalize(text) + " ";
        if (n.trim().isEmpty()) return null;
        for (Map.Entry<String, String[]> e : WORDS.entrySet()) {
            for (String w : e.getValue()) {
                if (n.contains(" " + w + " ")) return e.getKey();
            }
        }
        return null;
    }
}
