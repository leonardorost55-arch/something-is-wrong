package com.leonardo.somethingiswrong.item;

import com.leonardo.somethingiswrong.server.WatcherManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Olho de Vidro: detector. Se o Watcher estiver por perto, ele fica com contorno visivel por 5 s. Recarga de 20 s. */
public class GlassEyeItem extends Item {
    public static final int RADIUS = 64;
    public static final int GLOW_TICKS = 100;
    public static final int COOLDOWN_TICKS = 400;

    public GlassEyeItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            boolean found = WatcherManager.revealNear(sp, RADIUS, GLOW_TICKS);
            sp.sendMessage(Text.translatable(found ? "item.somethingiswrong.glass_eye.found" : "item.somethingiswrong.glass_eye.none")
                    .formatted(Formatting.GRAY, Formatting.ITALIC), true);
            sp.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
