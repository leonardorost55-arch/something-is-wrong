package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.campaign.CampaignState;
import com.leonardo.somethingiswrong.config.ModSettings;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Random;

public record ActionEnv(MinecraftServer server, ServerWorld world, ServerPlayerEntity player, CampaignState state,
                        ModSettings cfg, Random rnd) {}
