package com.leonardo.somethingiswrong.campaign;

import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;

/**
 * O Watcher evolui conforme a campanha (aparicoes + vezes que foi olhado + medo): 4 fases (0..3).
 * Fases altas ficam visiveis por mais tempo, se aproximam mais rapido e as vezes "piscam" para o lado.
 * Nunca causa dano: so tensao.
 */
public final class WatcherEvolution {
    public record Profile(int stage, int graceTicks, double stalkChance, int stalkIntervalTicks, double stalkStep,
                          double minApproach, double blinkChance, int lifetimeBonusTicks) {}

    private static final int[] GRACE = {10, 14, 20, 28};
    private static final double[] STALK_CHANCE = {0.0, 0.2, 0.5, 0.8};
    private static final int[] INTERVAL = {20, 16, 12, 9};
    private static final double[] STEP = {1.0, 1.0, 1.2, 1.5};
    private static final double[] MIN_APPROACH = {8.0, 7.0, 6.0, 5.0};
    private static final double[] BLINK = {0.0, 0.0, 0.25, 0.40};
    private static final int[] BONUS = {0, 20, 40, 60};

    private WatcherEvolution() {}

    public static int appearances(CampaignState s) {
        return s.countOf(AnomalyRegistry.WATCHER_VANISH) + s.countOf(AnomalyRegistry.WATCHER_FLICKER)
                + s.countOf(AnomalyRegistry.TREELINE) + s.countOf(AnomalyRegistry.TUNNEL)
                + s.countOf(AnomalyRegistry.BEHIND_CLOSE) + s.countOf(AnomalyRegistry.SILHOUETTE);
    }

    public static int score(int appearances, int looks, int fear) {
        return Math.max(0, appearances) + Math.max(0, looks) + Math.max(0, Math.min(100, fear)) / 25;
    }

    public static int stage(int score) {
        if (score < 5) return 0;
        if (score < 10) return 1;
        if (score < 16) return 2;
        return 3;
    }

    public static int stage(CampaignState s) {
        return stage(score(appearances(s), s.watcherLooks, s.fear));
    }

    public static Profile profile(int stage) {
        int i = Math.max(0, Math.min(3, stage));
        return new Profile(i, GRACE[i], STALK_CHANCE[i], INTERVAL[i], STEP[i], MIN_APPROACH[i], BLINK[i], BONUS[i]);
    }
}
