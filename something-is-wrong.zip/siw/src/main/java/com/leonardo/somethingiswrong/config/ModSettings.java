package com.leonardo.somethingiswrong.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Configuracoes do mod. Classe pura (sem dependencias do Minecraft) para poder ser testada. */
public final class ModSettings {
    public boolean enabled = true;
    /** 0..100. Escala chances de eventos e intensidade visual. */
    public int intensity = 50;
    /** 0.1..3.0. Multiplicador da frequencia de eventos. */
    public double eventFrequency = 1.0;
    public boolean visualInterference = true;
    public boolean customSounds = true;
    /** 3..60. Duracao da campanha em minutos (as fases escalam proporcionalmente). */
    public int campaignMinutes = 20;
    public boolean debug = false;
    /** Idioma da voz de narracao: "pt", "en" ou "off". */
    public String narrationLanguage = "pt";
    /** Mostra o texto da narracao na barra de acao (legenda). */
    public boolean narrationText = true;
    /** Inicia a campanha automaticamente quando o primeiro jogador entra no mundo. */
    public boolean autoStart = true;
    /** Se true, a campanha do mundo e reiniciada UMA vez na proxima carga (o flag volta a false). */
    public boolean resetCampaignOnNextStart = false;
    public double observationMinDistance = 2.0;
    public double observationMaxDistance = 96.0;
    /** Multiplicadores opcionais por anomalia (id -> 0..2). */
    public Map<String, Double> anomalyChance = new HashMap<>();

    public static ModSettings defaults() {
        return new ModSettings();
    }

    /** Corrige valores invalidos em memoria. Retorna avisos legiveis (vazio se nada mudou). */
    public List<String> sanitize() {
        List<String> w = new ArrayList<>();
        int i = clamp(intensity, 0, 100);
        if (i != intensity) { w.add("intensity fora de 0..100, usando " + i); intensity = i; }
        if (Double.isNaN(eventFrequency) || Double.isInfinite(eventFrequency)) {
            w.add("eventFrequency invalido, usando 1.0"); eventFrequency = 1.0;
        } else {
            double f = Math.max(0.1, Math.min(3.0, eventFrequency));
            if (f != eventFrequency) { w.add("eventFrequency fora de 0.1..3.0, usando " + f); eventFrequency = f; }
        }
        int m = clamp(campaignMinutes, 3, 60);
        if (m != campaignMinutes) { w.add("campaignMinutes fora de 3..60, usando " + m); campaignMinutes = m; }
        if (Double.isNaN(observationMinDistance) || observationMinDistance < 0.5 || observationMinDistance > 32) {
            w.add("observationMinDistance invalido, usando 2.0"); observationMinDistance = 2.0;
        }
        if (Double.isNaN(observationMaxDistance) || observationMaxDistance < observationMinDistance + 4 || observationMaxDistance > 256) {
            w.add("observationMaxDistance invalido, usando 96.0"); observationMaxDistance = 96.0;
        }
        String lang = narrationLanguage == null ? "" : narrationLanguage.trim().toLowerCase();
        if (!lang.equals("pt") && !lang.equals("en") && !lang.equals("off")) {
            w.add("narrationLanguage invalido, usando pt"); lang = "pt";
        }
        narrationLanguage = lang;
        if (anomalyChance == null) {
            anomalyChance = new HashMap<>();
        } else {
            Map<String, Double> ok = new HashMap<>();
            for (Map.Entry<String, Double> e : anomalyChance.entrySet()) {
                Double v = e.getValue();
                if (e.getKey() == null || v == null || v.isNaN() || v.isInfinite() || v < 0 || v > 2) {
                    w.add("anomalyChance[" + e.getKey() + "] invalido, ignorado");
                } else {
                    ok.put(e.getKey(), v);
                }
            }
            anomalyChance = ok;
        }
        return w;
    }

    public boolean narrationVoiceEnabled() {
        return !"off".equals(narrationLanguage);
    }

    public double intensityMultiplier() {
        return 0.5 + intensity / 100.0;
    }

    public double chanceMultiplierFor(String id) {
        Double v = anomalyChance == null ? null : anomalyChance.get(id);
        return v == null ? 1.0 : v;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
