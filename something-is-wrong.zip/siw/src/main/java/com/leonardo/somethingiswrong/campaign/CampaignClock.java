package com.leonardo.somethingiswrong.campaign;

import com.leonardo.somethingiswrong.config.ModSettings;

import java.util.Optional;

/** Relogio da campanha baseado em ticks do jogo (nao no relogio do computador). */
public final class CampaignClock {
    private CampaignClock() {}

    /** Avanca o relogio. Retorna a nova fase se houve transicao. */
    public static Optional<Phase> advance(CampaignState s, ModSettings cfg, long ticks) {
        if (!s.started || s.climax != ClimaxStatus.NOT_STARTED || ticks <= 0) return Optional.empty();
        s.elapsedTicks += ticks;
        Phase p = phaseOf(s, cfg);
        if (p != s.phase) {
            s.phase = p;
            return Optional.of(p);
        }
        return Optional.empty();
    }

    public static Phase phaseOf(CampaignState s, ModSettings cfg) {
        return Phase.atBaseSeconds(baseSeconds(s, cfg));
    }

    public static double baseSeconds(CampaignState s, ModSettings cfg) {
        return Phase.baseSeconds(s.elapsedTicks, cfg.campaignMinutes);
    }

    public static boolean finaleDue(CampaignState s, ModSettings cfg) {
        return s.started && s.climax == ClimaxStatus.NOT_STARTED
                && baseSeconds(s, cfg) >= Phase.FINALE_BASE_SECONDS;
    }

    /**
     * Se a duracao configurada mudou (config, comando ou menu), reescala o relogio para manter o MESMO progresso
     * proporcional (nao salta de fase). Retorna true se reescalou.
     */
    public static boolean syncLength(CampaignState s, int cfgMinutes) {
        if (cfgMinutes <= 0 || s.lengthMinutes == cfgMinutes) return false;
        if (s.lengthMinutes <= 0) {
            s.lengthMinutes = cfgMinutes;
            return false;
        }
        double ratio = (double) cfgMinutes / s.lengthMinutes;
        s.elapsedTicks = Math.round(s.elapsedTicks * ratio);
        if (s.lastEventTick >= 0) s.lastEventTick = Math.round(s.lastEventTick * ratio);
        if (s.lastAnyEventTick >= 0) s.lastAnyEventTick = Math.round(s.lastAnyEventTick * ratio);
        for (ExecutionRecord r : s.executed.values()) {
            if (r.lastTick >= 0) r.lastTick = Math.round(r.lastTick * ratio);
        }
        s.lengthMinutes = cfgMinutes;
        return true;
    }

    /** Ferramenta de teste: salta para o inicio da proxima fase (ou para o limiar do final). */
    public static void jumpToNextPhase(CampaignState s, ModSettings cfg) {
        if (!s.started || s.climax != ClimaxStatus.NOT_STARTED) return;
        Phase cur = phaseOf(s, cfg);
        double target = cur.ordinal() + 1 < Phase.values().length
                ? Phase.values()[cur.ordinal() + 1].startBaseSeconds
                : Phase.FINALE_BASE_SECONDS;
        s.elapsedTicks = Math.max(s.elapsedTicks, Phase.ticksForBaseSeconds(target, cfg.campaignMinutes));
        s.phase = phaseOf(s, cfg);
    }
}
