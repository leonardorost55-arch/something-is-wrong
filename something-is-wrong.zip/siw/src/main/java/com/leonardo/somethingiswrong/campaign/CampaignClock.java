package com.leonardo.somethingiswrong.campaign;

import com.leonardo.somethingiswrong.config.ModSettings;

import java.util.Optional;

/** Relogio da campanha baseado em ticks do jogo (nao no relogio do computador). */
public final class CampaignClock {
    private CampaignClock() {}

    /** Avanca o relogio. Retorna a nova fase se houve transicao. */
    public static Optional<Phase> advance(CampaignState s, ModSettings cfg, long ticks) {
        if (!s.started || s.climax != ClimaxStatus.NOT_STARTED || ticks <= 0) return Optional.empty();
        s.elapsedTicks += ticks;
        Phase p = phaseOf(s, cfg);
        if (p != s.phase) {
            s.phase = p;
            return Optional.of(p);
        }
        return Optional.empty();
    }

    public static Phase phaseOf(CampaignState s, ModSettings cfg) {
        return Phase.atBaseSeconds(baseSeconds(s, cfg));
    }

    public static double baseSeconds(CampaignState s, ModSettings cfg) {
        return Phase.baseSeconds(s.elapsedTicks, cfg.campaignMinutes);
    }

    public static boolean finaleDue(CampaignState s, ModSettings cfg) {
        return s.started && s.climax == ClimaxStatus.NOT_STARTED
                && baseSeconds(s, cfg) >= Phase.FINALE_BASE_SECONDS;
    }

    /** Ferramenta de teste: salta para o inicio da proxima fase (ou para o limiar do final). */
    public static void jumpToNextPhase(CampaignState s, ModSettings cfg) {
        if (!s.started || s.climax != ClimaxStatus.NOT_STARTED) return;
        Phase cur = phaseOf(s, cfg);
        double target = cur.ordinal() + 1 < Phase.values().length
                ? Phase.values()[cur.ordinal() + 1].startBaseSeconds
                : Phase.FINALE_BASE_SECONDS;
        s.elapsedTicks = Math.max(s.elapsedTicks, Phase.ticksForBaseSeconds(target, cfg.campaignMinutes));
        s.phase = phaseOf(s, cfg);
    }
}
