package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.anomaly.BehaviorTracker;
import com.leonardo.somethingiswrong.audio.Audio;
import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.campaign.Phase;
import com.leonardo.somethingiswrong.net.ModNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

/**
 * Efeitos concretos de cada anomalia. Cada acao retorna true se realmente aconteceu (so entao a execucao
 * e registrada no estado). Nenhuma acao altera blocos ou construcoes do jogador.
 */
public final class AnomalyActions {
    @FunctionalInterface
    public interface Action { boolean run(ActionEnv env); }

    private static final Map<String, Action> ACTIONS = new HashMap<>();
    private static String lastMessageKey = "";

    static {
        ACTIONS.put(AnomalyRegistry.FOOTSTEPS, AnomalyActions::footsteps);
        ACTIONS.put(AnomalyRegistry.SILHOUETTE, AnomalyActions::silhouette);
        ACTIONS.put(AnomalyRegistry.ODD_SOUND, AnomalyActions::oddSound);
        ACTIONS.put(AnomalyRegistry.LONE_MESSAGE, AnomalyActions::loneMessage);
        ACTIONS.put(AnomalyRegistry.WATCHER_FLICKER, AnomalyActions::watcherFlicker);
        ACTIONS.put(AnomalyRegistry.WATCHER_VANISH, AnomalyActions::watcherVanish);
        ACTIONS.put(AnomalyRegistry.CLOSE_NOISE, AnomalyActions::closeNoise);
        ACTIONS.put(AnomalyRegistry.INTERFERENCE, AnomalyActions::interference);
        ACTIONS.put(AnomalyRegistry.ADAPTIVE, AnomalyActions::adaptive);
    }

    private AnomalyActions() {}

    public static Action get(String id) { return ACTIONS.get(id); }

    // 1. Passos sem origem visivel (atras do jogador, aproximando-se sem nunca chegar perto demais)
    private static boolean footsteps(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        if (!p.isOnGround()) return false;
        BlockState below = e.world().getBlockState(p.getBlockPos().down());
        if (below.isAir()) return false;
        SoundEvent step = below.getSoundGroup().getStepSound();
        Vec3d dir = SpawnFinder.dir(p, Math.PI + (r.nextDouble() - 0.5));
        Vec3d start = p.getPos().add(dir.multiply(10));
        Vec3d end = p.getPos().add(dir.multiply(5.5));
        int steps = 4 + r.nextInt(3);
        long delay = 20 + r.nextInt(10);
        for (int i = 0; i < steps; i++) {
            Vec3d pos = start.lerp(end, i / (double) (steps - 1));
            float pitch = 0.85f + r.nextFloat() * 0.1f;
            DelayedTasks.schedule(delay, p.getUuid(), AnomalyRegistry.FOOTSTEPS, pl -> Audio.at(pl, step, pos, 0.55f, pitch));
            delay += 9 + r.nextInt(5);
        }
        return true;
    }

    // 2. Silhueta distante entre arvores (Watcher em modo silhueta, muito longe, some se observado)
    private static boolean silhouette(ActionEnv e) {
        Random r = e.rnd();
        SpawnFinder.Placement pl = r.nextBoolean() ? SpawnFinder.Placement.FRONT : SpawnFinder.Placement.PERIPHERAL;
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), pl, 38, 52, true, r);
        if (pos.isEmpty()) return false;
        return WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 70 + r.nextInt(40), 8, true, false));
    }

    // 3. Som vindo de uma direcao inesperada (atras/acima)
    private static boolean oddSound(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        Vec3d d = SpawnFinder.dir(p, Math.PI + (r.nextDouble() - 0.5) * 1.4);
        Vec3d pos = p.getPos().add(d.multiply(12 + r.nextDouble() * 8)).add(0, r.nextDouble() * 3, 0);
        SoundEvent s = switch (r.nextInt(4)) {
            case 0 -> ModSounds.WHISPER;
            case 1 -> ModSounds.CREAK;
            default -> ModSounds.DRONE;
        };
        return Audio.mod(p, s, pos, 0.7f, 0.9f + r.nextFloat() * 0.2f);
    }

    // 4. Mensagem isolada no chat (texto de sistema cinza e italico; nunca finge ser um jogador)
    private static boolean loneMessage(ActionEnv e) {
        Phase ph = e.state().phase;
        String tier;
        int count;
        if (ph.ordinal() >= Phase.RUPTURE.ordinal()) { tier = "t3"; count = 4; }
        else if (ph.ordinal() >= Phase.PRESENCE.ordinal()) { tier = "t2"; count = 3; }
        else { tier = "t1"; count = 3; }
        String key;
        int guard = 0;
        do {
            key = "message.somethingiswrong." + tier + "." + e.rnd().nextInt(count);
        } while (key.equals(lastMessageKey) && guard++ < 5);
        lastMessageKey = key;
        send(e.player(), key);
        return true;
    }

    private static void send(ServerPlayerEntity p, String key) {
        p.sendMessage(Text.translatable(key).formatted(Formatting.GRAY, Formatting.ITALIC), false);
    }

    // 5. Aparicao breve (na periferia / atras)
    private static boolean watcherFlicker(ActionEnv e) {
        Random r = e.rnd();
        SpawnFinder.Placement pl = r.nextBoolean() ? SpawnFinder.Placement.PERIPHERAL : SpawnFinder.Placement.BEHIND;
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), pl, 9, 15, false, r);
        if (pos.isEmpty()) return false;
        boolean ok = WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 50 + r.nextInt(30), 6, true, false));
        if (ok) Audio.mod(e.player(), ModSounds.WATCHER_AMBIENT, pos.get(), 0.4f, 1.0f);
        return ok;
    }

    // 6. Desaparecimento ao ser observado (aparece em campo de visao e some quando o jogador olha)
    private static boolean watcherVanish(ActionEnv e) {
        Random r = e.rnd();
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.FRONT, 14, 22, false, r);
        if (pos.isEmpty()) pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.PERIPHERAL, 12, 20, false, r);
        if (pos.isEmpty()) return false;
        boolean ok = WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 140, 10, true, r.nextInt(3) == 0));
        if (ok) Audio.mod(e.player(), ModSounds.WATCHER_AMBIENT, pos.get(), 0.5f, 0.95f);
        return ok;
    }

    // 7. Ruido ambiental proximo
    private static boolean closeNoise(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        Vec3d d = SpawnFinder.dir(p, r.nextDouble() * Math.PI * 2);
        Vec3d pos = p.getPos().add(d.multiply(2.5)).add(0, 1.5, 0);
        SoundEvent s = r.nextBoolean() ? ModSounds.BREATH : ModSounds.CREAK;
        return Audio.mod(p, s, pos, 0.5f, 0.9f + r.nextFloat() * 0.2f);
    }

    // 8. Interferencia visual temporaria (suave, sem estroboscopio; some ao abrir qualquer tela)
    private static boolean interference(ActionEnv e) {
        if (!e.cfg().visualInterference) return false;
        int intensity = (int) (30 + e.cfg().intensity * 0.4);
        ModNetworking.sendInterference(e.player(), 40 + e.rnd().nextInt(40), intensity);
        Audio.mod(e.player(), ModSounds.STATIC, e.player().getPos(), 0.3f, 1.0f);
        return true;
    }

    // 9. Evento que muda conforme o comportamento do jogador
    private static boolean adaptive(ActionEnv e) {
        BehaviorTracker t = CampaignManager.trackerFor(e.player());
        switch (t.dominant()) {
            case STATIONARY -> {
                footsteps(e);
                send(e.player(), "message.somethingiswrong.adaptive.stationary");
                return true;
            }
            case UNDERGROUND -> {
                Vec3d below = e.player().getPos().add(0, -6, 0);
                Audio.mod(e.player(), ModSounds.DRONE, below, 0.8f, 0.7f);
                send(e.player(), "message.somethingiswrong.adaptive.underground");
                return true;
            }
            case EXPLORER -> {
                send(e.player(), "message.somethingiswrong.adaptive.explorer");
                return true;
            }
            case LOOKER -> {
                send(e.player(), "message.somethingiswrong.adaptive.looker");
                t.consumeLooks();
                return true;
            }
            default -> {
                return false;
            }
        }
    }
}
