package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.anomaly.BehaviorTracker;
import com.leonardo.somethingiswrong.audio.Audio;
import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.audio.Narration;
import com.leonardo.somethingiswrong.campaign.AchievementIds;
import com.leonardo.somethingiswrong.campaign.CampaignState;
import com.leonardo.somethingiswrong.campaign.LoreSchedule;
import com.leonardo.somethingiswrong.campaign.Phase;
import com.leonardo.somethingiswrong.net.ModNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/**
 * Efeitos concretos de cada anomalia. Cada acao retorna true se realmente aconteceu (so entao a execucao
 * e registrada no estado). Nenhuma acao altera blocos ou construcoes do jogador.
 */
public final class AnomalyActions {
    @FunctionalInterface
    public interface Action { boolean run(ActionEnv env); }

    private static final Map<String, Action> ACTIONS = new HashMap<>();
    private static String lastMessageKey = "";

    static {
        ACTIONS.put(AnomalyRegistry.FOOTSTEPS, AnomalyActions::footsteps);
        ACTIONS.put(AnomalyRegistry.SILHOUETTE, AnomalyActions::silhouette);
        ACTIONS.put(AnomalyRegistry.ODD_SOUND, AnomalyActions::oddSound);
        ACTIONS.put(AnomalyRegistry.LONE_MESSAGE, AnomalyActions::loneMessage);
        ACTIONS.put(AnomalyRegistry.WATCHER_FLICKER, AnomalyActions::watcherFlicker);
        ACTIONS.put(AnomalyRegistry.WATCHER_VANISH, AnomalyActions::watcherVanish);
        ACTIONS.put(AnomalyRegistry.CLOSE_NOISE, AnomalyActions::closeNoise);
        ACTIONS.put(AnomalyRegistry.INTERFERENCE, AnomalyActions::interference);
        ACTIONS.put(AnomalyRegistry.ADAPTIVE, AnomalyActions::adaptive);
        ACTIONS.put(AnomalyRegistry.DIARY, AnomalyActions::diary);
        ACTIONS.put(AnomalyRegistry.TORCH_HISS, AnomalyActions::torchHiss);
        ACTIONS.put(AnomalyRegistry.DOOR_PHANTOM, AnomalyActions::doorPhantom);
        ACTIONS.put(AnomalyRegistry.KNOCK, AnomalyActions::knock);
        ACTIONS.put(AnomalyRegistry.ANIMALS_STARE, AnomalyActions::animalsStare);
        ACTIONS.put(AnomalyRegistry.DARKNESS, AnomalyActions::darkness);
        ACTIONS.put(AnomalyRegistry.STEPS_CIRCLE, AnomalyActions::stepsCircle);
        ACTIONS.put(AnomalyRegistry.TREELINE, AnomalyActions::treeline);
        ACTIONS.put(AnomalyRegistry.TUNNEL, AnomalyActions::tunnel);
        ACTIONS.put(AnomalyRegistry.MUSIC_BOX, AnomalyActions::musicBox);
        ACTIONS.put(AnomalyRegistry.HEARTBEAT, AnomalyActions::heartbeat);
        ACTIONS.put(AnomalyRegistry.BEHIND_CLOSE, AnomalyActions::behindClose);
    }

    private AnomalyActions() {}

    public static Action get(String id) { return ACTIONS.get(id); }

    /** Quantas aparicoes do Watcher ja ocorreram (usado para ele chegar cada vez mais perto). */
    private static int watcherAppearances(CampaignState s) {
        return s.countOf(AnomalyRegistry.WATCHER_VANISH) + s.countOf(AnomalyRegistry.WATCHER_FLICKER)
                + s.countOf(AnomalyRegistry.TREELINE) + s.countOf(AnomalyRegistry.TUNNEL)
                + s.countOf(AnomalyRegistry.BEHIND_CLOSE) + s.countOf(AnomalyRegistry.SILHOUETTE);
    }

    private static SoundEvent stepSoundBelow(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        if (!p.isOnGround()) return null;
        BlockState below = e.world().getBlockState(p.getBlockPos().down());
        if (below.isAir()) return null;
        return below.getSoundGroup().getStepSound();
    }

    // 1. Passos sem origem visivel (atras do jogador, aproximando-se sem nunca chegar perto demais)
    private static boolean footsteps(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        SoundEvent step = stepSoundBelow(e);
        if (step == null) return false;
        Vec3d dir = SpawnFinder.dir(p, Math.PI + (r.nextDouble() - 0.5));
        Vec3d start = p.getPos().add(dir.multiply(10));
        Vec3d end = p.getPos().add(dir.multiply(5.5));
        int steps = 4 + r.nextInt(3);
        long delay = 20 + r.nextInt(10);
        for (int i = 0; i < steps; i++) {
            Vec3d pos = start.lerp(end, i / (double) (steps - 1));
            float pitch = 0.85f + r.nextFloat() * 0.1f;
            DelayedTasks.schedule(delay, p.getUuid(), AnomalyRegistry.FOOTSTEPS, pl -> Audio.at(pl, step, pos, 0.55f, pitch));
            delay += 9 + r.nextInt(5);
        }
        return true;
    }

    // 2. Silhueta distante entre arvores
    private static boolean silhouette(ActionEnv e) {
        Random r = e.rnd();
        SpawnFinder.Placement pl = r.nextBoolean() ? SpawnFinder.Placement.FRONT : SpawnFinder.Placement.PERIPHERAL;
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), pl, 38, 52, true, r);
        if (pos.isEmpty()) return false;
        return WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 70 + r.nextInt(40), 8, true, false));
    }

    // 3. Som vindo de uma direcao inesperada (atras/acima)
    private static boolean oddSound(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        Vec3d d = SpawnFinder.dir(p, Math.PI + (r.nextDouble() - 0.5) * 1.4);
        Vec3d pos = p.getPos().add(d.multiply(8 + r.nextDouble() * 6)).add(0, r.nextDouble() * 3, 0);
        SoundEvent s = switch (r.nextInt(4)) {
            case 0 -> ModSounds.WHISPER;
            case 1 -> ModSounds.CREAK;
            default -> ModSounds.DRONE;
        };
        return Audio.mod(p, s, pos, 0.8f, 0.9f + r.nextFloat() * 0.2f);
    }

    // 4. Mensagem isolada no chat
    private static boolean loneMessage(ActionEnv e) {
        Phase ph = e.state().phase;
        String tier;
        int count;
        if (ph.ordinal() >= Phase.RUPTURE.ordinal()) { tier = "t3"; count = 6; }
        else if (ph.ordinal() >= Phase.PRESENCE.ordinal()) { tier = "t2"; count = 4; }
        else { tier = "t1"; count = 4; }
        String key;
        int guard = 0;
        do {
            key = "message.somethingiswrong." + tier + "." + e.rnd().nextInt(count);
        } while (key.equals(lastMessageKey) && guard++ < 5);
        lastMessageKey = key;
        e.player().sendMessage(Text.translatable(key).formatted(Formatting.GRAY, Formatting.ITALIC), false);
        return true;
    }

    // 5. Aparicao breve (periferia / atras)
    private static boolean watcherFlicker(ActionEnv e) {
        Random r = e.rnd();
        SpawnFinder.Placement pl = r.nextBoolean() ? SpawnFinder.Placement.PERIPHERAL : SpawnFinder.Placement.BEHIND;
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), pl, 9, 15, false, r);
        if (pos.isEmpty()) return false;
        boolean ok = WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 50 + r.nextInt(30), 6, true, false));
        if (ok) Audio.mod(e.player(), ModSounds.WATCHER_AMBIENT, pos.get(), 0.4f, 1.0f);
        return ok;
    }

    // 6. Desaparecimento ao ser observado. A cada aparicao ele surge um pouco mais perto.
    private static boolean watcherVanish(ActionEnv e) {
        Random r = e.rnd();
        double maxD = Math.max(10.0, 22.0 - 1.5 * watcherAppearances(e.state()));
        double minD = Math.max(7.0, maxD - 8.0);
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.FRONT, minD, maxD, false, r);
        if (pos.isEmpty()) pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.PERIPHERAL, minD, maxD, false, r);
        if (pos.isEmpty()) return false;
        boolean ok = WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 140, 10, true, r.nextInt(3) == 0));
        if (ok) Audio.mod(e.player(), ModSounds.WATCHER_AMBIENT, pos.get(), 0.5f, 0.95f);
        return ok;
    }

    // 7. Ruido ambiental proximo
    private static boolean closeNoise(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        Vec3d d = SpawnFinder.dir(p, r.nextDouble() * Math.PI * 2);
        Vec3d pos = p.getPos().add(d.multiply(2.5)).add(0, 1.5, 0);
        SoundEvent s = r.nextBoolean() ? ModSounds.BREATH : ModSounds.CREAK;
        return Audio.mod(p, s, pos, 0.5f, 0.9f + r.nextFloat() * 0.2f);
    }

    // 8. Interferencia visual temporaria
    private static boolean interference(ActionEnv e) {
        if (!e.cfg().visualInterference) return false;
        int intensity = (int) (30 + e.cfg().intensity * 0.4);
        ModNetworking.sendInterference(e.player(), 40 + e.rnd().nextInt(40), intensity);
        Audio.mod(e.player(), ModSounds.STATIC, e.player().getPos(), 0.3f, 1.0f);
        return true;
    }

    // 9. Evento que muda conforme o comportamento do jogador (agora com voz)
    private static boolean adaptive(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        BehaviorTracker t = CampaignManager.trackerFor(p);
        switch (t.dominant()) {
            case STATIONARY -> {
                footsteps(e);
                Narration.say(p, "r_still");
                Achievements.grant(p, AchievementIds.WHY_STOP);
                return true;
            }
            case UNDERGROUND -> {
                Audio.mod(p, ModSounds.DRONE, p.getPos().add(0, -6, 0), 0.8f, 0.7f);
                Narration.say(p, "r_under");
                Achievements.grant(p, AchievementIds.TOO_DEEP);
                return true;
            }
            case EXPLORER -> {
                Narration.say(p, "r_walk");
                return true;
            }
            case LOOKER -> {
                Narration.say(p, "r_look");
                t.consumeLooks();
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    // 10 (lore). Diario do Primeiro Jogador: um fragmento por vez, em ordem
    private static boolean diary(ActionEnv e) {
        CampaignState st = e.state();
        double base = Phase.baseSeconds(st.elapsedTicks, e.cfg().campaignMinutes);
        int idx = LoreSchedule.next(st.loreMask, base);
        if (idx < 0) return false;
        Narration.say(e.player(), LoreSchedule.key(idx));
        st.loreMask = LoreSchedule.mark(st.loreMask, idx);
        if (LoreSchedule.count(st.loreMask) >= 4) Achievements.grant(e.player(), AchievementIds.DIARY_START);
        return true;
    }

    // Tocha chia (som de apagar + fumaca) sem remover nada
    private static boolean torchHiss(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        BlockPos c = p.getBlockPos();
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -10; dx <= 10; dx++) {
            for (int dy = -4; dy <= 5; dy++) {
                for (int dz = -10; dz <= 10; dz++) {
                    BlockPos bp = c.add(dx, dy, dz);
                    BlockState bs = e.world().getBlockState(bp);
                    if (bs.isOf(Blocks.TORCH) || bs.isOf(Blocks.WALL_TORCH) || bs.isOf(Blocks.SOUL_TORCH)
                            || bs.isOf(Blocks.SOUL_WALL_TORCH)) {
                        found.add(bp);
                    }
                }
            }
        }
        if (found.isEmpty()) return false;
        BlockPos t = found.get(e.rnd().nextInt(found.size()));
        Vec3d pos = Vec3d.ofCenter(t);
        Audio.at(p, SoundEvents.BLOCK_FIRE_EXTINGUISH, pos, 0.7f, 0.9f);
        e.world().spawnParticles(ParticleTypes.SMOKE, pos.x, pos.y + 0.2, pos.z, 8, 0.05, 0.1, 0.05, 0.01);
        return true;
    }

    // Porta que abre e fecha em algum lugar (apenas som)
    private static boolean doorPhantom(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        Vec3d d = SpawnFinder.dir(p, Math.PI + (r.nextDouble() - 0.5) * 1.6);
        Vec3d pos = p.getPos().add(d.multiply(7 + r.nextDouble() * 6));
        Audio.at(p, SoundEvents.BLOCK_WOODEN_DOOR_OPEN, pos, 0.8f, 0.9f);
        DelayedTasks.schedule(25 + r.nextInt(20), p.getUuid(), AnomalyRegistry.DOOR_PHANTOM,
                pl -> Audio.at(pl, SoundEvents.BLOCK_WOODEN_DOOR_CLOSE, pos, 0.8f, 0.9f));
        return true;
    }

    // Tres batidas perto, sem origem
    private static boolean knock(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Vec3d d = SpawnFinder.dir(p, Math.PI + (e.rnd().nextDouble() - 0.5));
        return Audio.mod(p, ModSounds.KNOCK, p.getPos().add(d.multiply(3.0)).add(0, 1.2, 0), 0.9f, 1.0f);
    }

    // Animais proximos param e olham para o jogador
    private static boolean animalsStare(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        List<AnimalEntity> animals = e.world().getEntitiesByClass(AnimalEntity.class,
                p.getBoundingBox().expand(16.0), a -> a.isAlive());
        if (animals.size() < 2) return false;
        List<UUID> ids = new ArrayList<>();
        for (int i = 0; i < Math.min(6, animals.size()); i++) ids.add(animals.get(i).getUuid());
        for (int t = 0; t < 12; t++) {
            DelayedTasks.schedule(t * 5L, p.getUuid(), AnomalyRegistry.ANIMALS_STARE, pl -> {
                for (UUID id : ids) {
                    Entity en = pl.getServerWorld().getEntity(id);
                    if (en instanceof AnimalEntity a && a.isAlive()) {
                        a.getNavigation().stop();
                        a.getLookControl().lookAt(pl);
                    }
                }
            });
        }
        return true;
    }

    // Escurecimento curto (efeito vanilla Escuridao, 5 s, sem particulas)
    private static boolean darkness(ActionEnv e) {
        if (!e.cfg().visualInterference) return false;
        ServerPlayerEntity p = e.player();
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0, true, false, false));
        Audio.mod(p, ModSounds.DRONE, p.getPos(), 0.6f, 0.75f);
        return true;
    }

    // Passos dando a volta no jogador
    private static boolean stepsCircle(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        Random r = e.rnd();
        SoundEvent step = stepSoundBelow(e);
        if (step == null) return false;
        double a0 = r.nextDouble() * Math.PI * 2;
        double dir = r.nextBoolean() ? 1 : -1;
        long delay = 15;
        for (int i = 0; i < 9; i++) {
            double a = a0 + dir * i * Math.toRadians(38);
            Vec3d pos = p.getPos().add(Math.cos(a) * 6.5, 0, Math.sin(a) * 6.5);
            DelayedTasks.schedule(delay, p.getUuid(), AnomalyRegistry.STEPS_CIRCLE, pl -> Audio.at(pl, step, pos, 0.6f, 0.85f));
            delay += 11;
        }
        return true;
    }

    // Watcher parado na linha das arvores
    private static boolean treeline(ActionEnv e) {
        Random r = e.rnd();
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.PERIPHERAL, 16, 26, true, r);
        if (pos.isEmpty()) pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.FRONT, 16, 26, true, r);
        if (pos.isEmpty()) return false;
        return WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 90 + r.nextInt(40), 8, true, false));
    }

    // Watcher no fim de um tunel / caverna
    private static boolean tunnel(ActionEnv e) {
        Random r = e.rnd();
        Optional<Vec3d> pos = SpawnFinder.find(e.world(), e.player(), SpawnFinder.Placement.FRONT, 12, 20, false, r);
        if (pos.isEmpty()) return false;
        boolean ok = WatcherManager.spawn(e.world(), e.player(), pos.get(),
                new WatcherManager.Session(e.player().getUuid(), 100, 6, true, false));
        if (ok) Audio.mod(e.player(), ModSounds.WATCHER_AMBIENT, pos.get(), 0.5f, 0.85f);
        return ok;
    }

    // Caixa de musica desafinada, muito longe
    private static boolean musicBox(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        Vec3d d = SpawnFinder.dir(p, e.rnd().nextDouble() * Math.PI * 2);
        return Audio.mod(p, ModSounds.MUSIC_BOX, p.getPos().add(d.multiply(16 + e.rnd().nextDouble() * 6)), 1.7f, 1.0f);
    }

    // Batimentos que sobem
    private static boolean heartbeat(ActionEnv e) {
        if (!e.cfg().customSounds) return false;
        ServerPlayerEntity p = e.player();
        float[] vol = {0.5f, 0.7f, 0.9f, 1.0f};
        long[] at = {0, 24, 44, 60};
        for (int i = 0; i < vol.length; i++) {
            float v = vol[i];
            DelayedTasks.schedule(at[i], p.getUuid(), AnomalyRegistry.HEARTBEAT, pl -> Audio.mod(pl, ModSounds.HEARTBEAT, pl.getPos(), v, 1.0f));
        }
        return true;
    }

    // Voz avisa "estou atras de voce" e ele aparece perto, atras; some assim que voce vira
    private static boolean behindClose(ActionEnv e) {
        ServerPlayerEntity p = e.player();
        Narration.say(p, "r_close");
        DelayedTasks.schedule(45, p.getUuid(), AnomalyRegistry.BEHIND_CLOSE, pl -> {
            Optional<Vec3d> pos = SpawnFinder.find(pl.getServerWorld(), pl, SpawnFinder.Placement.BEHIND, 5, 7, false, new Random());
            pos.ifPresent(v -> WatcherManager.spawn(pl.getServerWorld(), pl, v,
                    new WatcherManager.Session(pl.getUuid(), 80, 4, true, false)));
        });
        return true;
    }
}
