package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.campaign.AchievementIds;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.advancement.PlayerAdvancementTracker;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.ServerAdvancementLoader;
import net.minecraft.server.network.ServerPlayerEntity;

/** Concede conquistas (advancements com criterio "impossible", liberados so por codigo). */
public final class Achievements {
    private Achievements() {}

    public static void grant(ServerPlayerEntity p, String id) {
        try {
            MinecraftServer server = p.getServer();
            if (server == null) return;
            ServerAdvancementLoader loader = server.getAdvancementLoader();
            AdvancementEntry entry = loader.get(SomethingIsWrongMod.id(id));
            if (entry == null) return;
            AdvancementEntry root = loader.get(SomethingIsWrongMod.id(AchievementIds.ROOT));
            PlayerAdvancementTracker tracker = p.getAdvancementTracker();
            if (root != null) tracker.grantCriterion(root, "trigger");
            tracker.grantCriterion(entry, "trigger");
        } catch (Exception e) {
            SomethingIsWrongMod.LOGGER.warn("Falha ao conceder conquista {}: {}", id, e.toString());
        }
    }
}
