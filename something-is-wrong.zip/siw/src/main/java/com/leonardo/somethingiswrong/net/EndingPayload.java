package com.leonardo.somethingiswrong.net;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

/** Servidor -> cliente: abre a tela de encerramento. */
public record EndingPayload(int variant) implements CustomPayload {
    public static final CustomPayload.Id<EndingPayload> ID = new CustomPayload.Id<>(SomethingIsWrongMod.id("ending"));
    public static final PacketCodec<RegistryByteBuf, EndingPayload> CODEC = PacketCodec.tuple(
            net.minecraft.network.codec.PacketCodecs.VAR_INT, EndingPayload::variant, EndingPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
