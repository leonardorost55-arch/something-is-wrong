package com.leonardo.somethingiswrong.anomaly;

/** Retrato do estado do jogador usado para decidir se um evento pode ocorrer. Sem dependencias do Minecraft. */
public record SafetyContext(boolean spectator, boolean inCombat, boolean hostileNearby, boolean lowHealth,
                            boolean inLiquid, boolean onFire, boolean falling, boolean underground,
                            boolean watcherPresent) {

    public static SafetyContext calm() {
        return new SafetyContext(false, false, false, false, false, false, false, false, false);
    }

    public boolean isSafeForEvents() {
        return !spectator && !inCombat && !hostileNearby && !lowHealth && !inLiquid && !onFire && !falling;
    }

    public SafetyContext withUnderground(boolean u) {
        return new SafetyContext(spectator, inCombat, hostileNearby, lowHealth, inLiquid, onFire, falling, u, watcherPresent);
    }

    public SafetyContext withWatcherPresent(boolean w) {
        return new SafetyContext(spectator, inCombat, hostileNearby, lowHealth, inLiquid, onFire, falling, underground, w);
    }

    public SafetyContext withInCombat(boolean c) {
        return new SafetyContext(spectator, c, hostileNearby, lowHealth, inLiquid, onFire, falling, underground, watcherPresent);
    }
}
