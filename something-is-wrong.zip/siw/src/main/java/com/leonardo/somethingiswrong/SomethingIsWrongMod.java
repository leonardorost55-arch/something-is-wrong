package com.leonardo.somethingiswrong;

import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.debug.DebugCommands;
import com.leonardo.somethingiswrong.entity.ModEntities;
import com.leonardo.somethingiswrong.item.ModItems;
import com.leonardo.somethingiswrong.net.ModNetworking;
import com.leonardo.somethingiswrong.server.CampaignManager;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Ponto de entrada comum (cliente + servidor): apenas inicializacao e registros. */
public class SomethingIsWrongMod implements ModInitializer {
    public static final String MOD_ID = "somethingiswrong";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ConfigManager.load();
        ModSounds.register();
        ModEntities.register();
        ModItems.register();
        ModNetworking.registerPayloads();
        CampaignManager.register();
        DebugCommands.register();
        LOGGER.info("Something Is Wrong inicializado.");
    }
}
