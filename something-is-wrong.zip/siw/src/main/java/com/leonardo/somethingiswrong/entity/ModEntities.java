package com.leonardo.somethingiswrong.entity;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
    public static final EntityType<WatcherEntity> THE_WATCHER = Registry.register(
            Registries.ENTITY_TYPE,
            SomethingIsWrongMod.id("the_watcher"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, WatcherEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 2.1f))
                    .trackRangeBlocks(128)
                    .build());

    private ModEntities() {}

    public static void register() {
        FabricDefaultAttributeRegistry.register(THE_WATCHER, WatcherEntity.createWatcherAttributes());
    }
}
