package com.leonardo.somethingiswrong.server;

import net.minecraft.block.BlockState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.RaycastContext;

import java.util.Optional;
import java.util.Random;

/** Procura posicoes coerentes com o ambiente (chao solido, espaco livre, chunk carregado). */
public final class SpawnFinder {
    public enum Placement { FRONT, PERIPHERAL, BEHIND, ANY }

    private SpawnFinder() {}

    /** Direcao horizontal (unitaria) relativa ao olhar do jogador; angulo em radianos (0 = a frente). */
    public static Vec3d dir(ServerPlayerEntity p, double offsetRad) {
        double a = Math.toRadians(p.getYaw()) + offsetRad;
        return new Vec3d(-Math.sin(a), 0, Math.cos(a));
    }

    private static double angleFor(Placement pl, Random r) {
        return switch (pl) {
            case FRONT -> Math.toRadians((r.nextDouble() * 50 - 25));
            case PERIPHERAL -> Math.toRadians((r.nextBoolean() ? 1 : -1) * (50 + r.nextDouble() * 30));
            case BEHIND -> Math.PI + Math.toRadians(r.nextDouble() * 80 - 40);
            case ANY -> r.nextDouble() * Math.PI * 2;
        };
    }

    public static Optional<Vec3d> find(ServerWorld w, ServerPlayerEntity p, Placement pl, double min, double max,
                                       boolean needTrees, Random r) {
        boolean underground = !w.isSkyVisible(p.getBlockPos());
        for (int attempt = 0; attempt < 30; attempt++) {
            double dist = min + r.nextDouble() * (max - min);
            Vec3d d = dir(p, angleFor(pl, r));
            double x = p.getX() + d.x * dist;
            double z = p.getZ() + d.z * dist;
            int bx = MathHelper.floor(x), bz = MathHelper.floor(z);
            if (!w.getChunkManager().isChunkLoaded(bx >> 4, bz >> 4)) continue;
            Integer y = underground ? findCaveY(w, bx, bz, p.getBlockY()) : Integer.valueOf(w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, bx, bz));
            if (y == null) continue;
            BlockPos feet = new BlockPos(bx, y, bz);
            if (!standable(w, feet)) continue;
            if (needTrees && !logsNear(w, feet)) continue;
            Vec3d pos = new Vec3d(bx + 0.5, y, bz + 0.5);
            if (pl == Placement.FRONT && !clearLine(w, p, pos.add(0, 1.6, 0))) continue;
            return Optional.of(pos);
        }
        return Optional.empty();
    }

    private static Integer findCaveY(ServerWorld w, int x, int z, int py) {
        for (int y = py + 3; y >= py - 5; y--) {
            BlockPos feet = new BlockPos(x, y, z);
            if (standable(w, feet)) return y;
        }
        return null;
    }

    private static boolean standable(ServerWorld w, BlockPos feet) {
        BlockState below = w.getBlockState(feet.down());
        return w.getBlockState(feet).isAir() && w.getBlockState(feet.up()).isAir()
                && w.getBlockState(feet.up(2)).isAir()
                && below.isSolidBlock(w, feet.down()) && w.getFluidState(feet.down()).isEmpty();
    }

    private static boolean logsNear(ServerWorld w, BlockPos feet) {
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = 0; dy <= 6; dy++) {
                    if (w.getBlockState(feet.add(dx, dy, dz)).isIn(BlockTags.LOGS)) return true;
                }
            }
        }
        return false;
    }

    /** Linha de visao livre entre o olho do jogador e um ponto. */
    public static boolean clearLine(ServerWorld w, ServerPlayerEntity p, Vec3d target) {
        HitResult hit = w.raycast(new RaycastContext(p.getEyePos(), target, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        return hit.getType() == HitResult.Type.MISS;
    }
}
