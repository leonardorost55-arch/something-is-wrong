package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.anomaly.SafetyContext;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Fila de tarefas atrasadas (efeitos de uma anomalia que se desenrolam em varios ticks).
 * Condicoes de cancelamento: jogador saiu, morreu, virou espectador ou ficou em situacao insegura
 * (combate, lava/agua, fogo, queda, pouca vida). Tarefas sao apenas cosmeticas e nao persistem.
 */
public final class DelayedTasks {
    private record Task(long runAt, UUID player, String anomalyId, Consumer<ServerPlayerEntity> action) {}

    private static final List<Task> TASKS = new ArrayList<>();
    private static long now = 0;

    private DelayedTasks() {}

    public static void schedule(long delayTicks, UUID player, String anomalyId, Consumer<ServerPlayerEntity> action) {
        TASKS.add(new Task(now + Math.max(0, delayTicks), player, anomalyId, action));
    }

    public static void tick(MinecraftServer server) {
        now++;
        if (TASKS.isEmpty()) return;
        Iterator<Task> it = TASKS.iterator();
        List<Task> due = new ArrayList<>();
        while (it.hasNext()) {
            Task t = it.next();
            if (t.runAt <= now) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(t.player);
            if (p == null || !p.isAlive()) {
                CampaignManager.debugLog("cancelado " + t.anomalyId + " (jogador ausente)");
                continue;
            }
            SafetyContext c = ContextBuilder.build(p);
            if (!c.isSafeForEvents()) {
                CampaignManager.debugLog("cancelado " + t.anomalyId + " (situacao insegura)");
                continue;
            }
            try {
                t.action.accept(p);
            } catch (Exception e) {
                SomethingIsWrongMod.LOGGER.warn("Falha em tarefa de {}: {}", t.anomalyId, e.toString());
            }
        }
    }

    public static void clear() {
        TASKS.clear();
    }
}
