package com.leonardo.somethingiswrong.campaign;

/** Qual final o jogador recebe, conforme o comportamento. */
public final class EndingVariant {
    public static final int IGNORED = 0;
    public static final int LOOKED = 1;
    public static final int CONVERSED = 2;
    public static final int LOOKS_THRESHOLD = 4;
    public static final int REPLIES_THRESHOLD = 3;

    private EndingVariant() {}

    /** Quem conversou com o Watcher no chat 3+ vezes tem prioridade; depois quem olhou 4+ vezes. */
    public static int choose(int watcherLooks, int chatReplies) {
        if (chatReplies >= REPLIES_THRESHOLD) return CONVERSED;
        return watcherLooks >= LOOKS_THRESHOLD ? LOOKED : IGNORED;
    }
}
