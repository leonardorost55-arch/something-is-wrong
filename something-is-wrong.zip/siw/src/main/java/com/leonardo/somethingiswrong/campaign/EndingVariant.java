package com.leonardo.somethingiswrong.campaign;

/** Qual final o jogador recebe, conforme o comportamento: quem olhou muito para o Watcher ve outro final. */
public final class EndingVariant {
    public static final int IGNORED = 0;
    public static final int LOOKED = 1;
    public static final int LOOKS_THRESHOLD = 4;

    private EndingVariant() {}

    public static int choose(int watcherLooks) {
        return watcherLooks >= LOOKS_THRESHOLD ? LOOKED : IGNORED;
    }
}
