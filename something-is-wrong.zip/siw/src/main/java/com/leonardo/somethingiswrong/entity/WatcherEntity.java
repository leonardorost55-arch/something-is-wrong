package com.leonardo.somethingiswrong.entity;

import com.leonardo.somethingiswrong.server.WatcherManager;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.World;

/**
 * The Watcher. Entidade passiva, invulneravel, sem IA propria, sem drops e sem XP.
 * Todo o comportamento (observacao, desaparecimento, vida util) e controlado por
 * {@link WatcherManager}. Entidades que nao pertencem a uma sessao ativa (ex.: restauradas de um
 * salvamento antigo) se descartam sozinhas, o que impede duplicatas apos reiniciar.
 */
public class WatcherEntity extends MobEntity {

    public WatcherEntity(EntityType<? extends WatcherEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        this.setInvulnerable(true);
        this.setSilent(true); // sons sao tocados pelo gerenciador, so para o jogador alvo
    }

    public static DefaultAttributeContainer.Builder createWatcherAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.2);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient) {
            WatcherManager.onWatcherTick(this);
        }
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }
}
