package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.audio.Audio;
import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.audio.Narration;
import com.leonardo.somethingiswrong.campaign.AchievementIds;
import com.leonardo.somethingiswrong.campaign.FearModel;
import com.leonardo.somethingiswrong.campaign.WatcherEvolution;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.entity.ModEntities;
import com.leonardo.somethingiswrong.entity.WatcherEntity;
import com.leonardo.somethingiswrong.observation.ObservationMath;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Ciclo de vida do Watcher. No maximo UMA entidade ativa por vez. Cada entidade pertence a uma sessao;
 * entidades sem sessao (ex.: restauradas do disco) sao descartadas pelo proprio tick.
 * O Watcher evolui (WatcherEvolution) e nunca causa dano.
 */
public final class WatcherManager {
    /** vanishOnLook: some ao ser observado. stalk: se aproxima devagar enquanto nao e observado. */
    public record Session(UUID target, int maxAge, int grace, boolean vanishOnLook, boolean stalk) {}

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static final Map<UUID, Boolean> OBSERVED = new HashMap<>();
    private static final Map<UUID, Integer> SPY_UNTIL = new HashMap<>();
    private static final double HALF_ANGLE = 28.0;
    private static final int CHECK_INTERVAL = 5; // observacao a cada 5 ticks, nao a cada quadro

    private WatcherManager() {}

    public static boolean isPresent() { return !SESSIONS.isEmpty(); }

    public static boolean spawn(ServerWorld w, ServerPlayerEntity target, Vec3d pos, Session s) {
        if (isPresent()) return false; // nunca duplica
        WatcherEntity e = ModEntities.THE_WATCHER.create(w);
        if (e == null) return false;
        int stage = WatcherEvolution.stage(CampaignManager.state());
        WatcherEvolution.Profile prof = WatcherEvolution.profile(stage);
        boolean stalk = s.stalk() || (s.vanishOnLook() && w.getRandom().nextDouble() < prof.stalkChance());
        int grace = s.vanishOnLook() ? Math.max(s.grace(), prof.graceTicks()) : s.grace();
        Session merged = new Session(s.target(), s.maxAge() + prof.lifetimeBonusTicks(), grace, s.vanishOnLook(), stalk);
        e.setStage(stage);
        float yaw = yawToward(pos, target.getPos());
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, 0f);
        e.setHeadYaw(yaw);
        e.setBodyYaw(yaw);
        SESSIONS.put(e.getUuid(), merged);
        if (!w.spawnEntity(e)) {
            SESSIONS.remove(e.getUuid());
            return false;
        }
        CampaignManager.state().watcherUuid = e.getUuid().toString();
        return true;
    }

    private static float yawToward(Vec3d from, Vec3d to) {
        return (float) (MathHelper.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90.0f;
    }

    public static void onWatcherTick(WatcherEntity e) {
        Session s = SESSIONS.get(e.getUuid());
        if (s == null) { e.discard(); return; }
        if (!(e.getWorld() instanceof ServerWorld w)) return;
        MinecraftServer server = w.getServer();
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(s.target());
        if (p == null || p.isSpectator() || p.getServerWorld() != w || !p.isAlive()) { remove(e); return; }

        // olha sempre para o jogador
        float yaw = yawToward(e.getPos(), p.getPos());
        e.setYaw(yaw);
        e.setHeadYaw(yaw);
        e.setBodyYaw(yaw);

        if (e.age >= s.maxAge()) { fade(w, p, e); return; }
        UUID id = e.getUuid();
        WatcherEvolution.Profile prof = WatcherEvolution.profile(e.getStage());

        if (e.age % CHECK_INTERVAL == 0) {
            ModSettings cfg = ConfigManager.get();
            Vec3d eye = p.getEyePos();
            Vec3d look = p.getRotationVec(1.0f);
            Vec3d t = e.getEyePos();
            ObservationMath.View view = ObservationMath.classify(eye.x, eye.y, eye.z, look.x, look.y, look.z,
                    t.x, t.y, t.z, cfg.observationMinDistance, cfg.observationMaxDistance, HALF_ANGLE);
            boolean observed = view == ObservationMath.View.IN_VIEW && SpawnFinder.clearLine(w, p, t);
            OBSERVED.put(id, observed);

            // Olhar pela luneta: ele "olha de volta" por 1,5 s antes de sumir
            if (observed && s.vanishOnLook() && p.isUsingSpyglass() && e.age >= s.grace()) {
                Integer until = SPY_UNTIL.get(id);
                if (until == null) {
                    SPY_UNTIL.put(id, e.age + 30);
                    Narration.say(p, "r_zoom");
                    Audio.mod(p, ModSounds.HEARTBEAT, p.getPos(), 1.0f, 1.1f);
                    Achievements.grant(p, AchievementIds.ZOOM);
                    CampaignManager.addFear(FearModel.GAIN_WATCHER_SEEN * 2);
                    return;
                }
                if (e.age < until) return;
                SPY_UNTIL.remove(id);
                CampaignManager.onWatcherSeen(p);
                fade(w, p, e);
                return;
            }
            if (observed && s.vanishOnLook() && e.age >= s.grace()) {
                CampaignManager.onWatcherSeen(p);
                fade(w, p, e);
                return;
            }
            if (e.age % 100 == 50) Audio.mod(p, ModSounds.WATCHER_AMBIENT, e.getPos(), 0.35f, 1.0f);
            // batimento cardiaco que aumenta conforme ele se aproxima
            if (e.age % 40 == 0) {
                double d = e.distanceTo(p);
                if (d < 18.0) Audio.mod(p, ModSounds.HEARTBEAT, p.getPos(), (float) (0.15 + 0.85 * (1.0 - d / 18.0)), 1.0f);
            }
        }

        boolean observedNow = Boolean.TRUE.equals(OBSERVED.get(id));
        if (!observedNow && s.stalk() && e.age % prof.stalkIntervalTicks() == 0) stalkStep(w, p, e, prof);
        if (!observedNow && prof.blinkChance() > 0 && e.age % 60 == 0 && e.getRandom().nextDouble() < prof.blinkChance()) {
            blink(w, p, e, prof);
        }
    }

    /** Aproxima-se um passo, mas nunca alem de minApproach. So acontece quando ninguem esta olhando. */
    private static void stalkStep(ServerWorld w, ServerPlayerEntity p, WatcherEntity e, WatcherEvolution.Profile prof) {
        Vec3d to = p.getPos().subtract(e.getPos());
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        if (flat <= prof.minApproach() || Math.abs(to.y) > 3.0) return;
        Vec3d step = new Vec3d(to.x / flat, 0, to.z / flat).multiply(prof.stalkStep());
        tryMove(w, e, e.getPos().add(step));
    }

    /** Fase 2+: reaparece um pouco ao lado (imprevisivel), sem chegar mais perto que o minimo. */
    private static void blink(ServerWorld w, ServerPlayerEntity p, WatcherEntity e, WatcherEvolution.Profile prof) {
        Vec3d to = p.getPos().subtract(e.getPos());
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        if (flat < 1.0 || Math.abs(to.y) > 3.0) return;
        double side = e.getRandom().nextBoolean() ? 1 : -1;
        double len = 2.0 + e.getRandom().nextDouble() * 2.0;
        Vec3d np = e.getPos().add(new Vec3d(-to.z / flat, 0, to.x / flat).multiply(side * len));
        if (np.distanceTo(p.getPos()) < prof.minApproach()) return;
        tryMove(w, e, np);
    }

    private static void tryMove(ServerWorld w, WatcherEntity e, Vec3d np) {
        BlockPos feet = BlockPos.ofFloored(np.x, e.getY(), np.z);
        if (w.getBlockState(feet).isAir() && w.getBlockState(feet.up()).isAir()
                && w.getBlockState(feet.down()).isSolidBlock(w, feet.down())) {
            e.refreshPositionAndAngles(np.x, e.getY(), np.z, e.getYaw(), 0f);
        }
    }

    /** Desaparecimento controlado: fumaca, som, sem drops, sem XP, sem vestigios. */
    private static void fade(ServerWorld w, ServerPlayerEntity p, WatcherEntity e) {
        w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1.0, e.getZ(), 14, 0.25, 0.7, 0.25, 0.01);
        Audio.mod(p, ModSounds.WATCHER_VANISH, e.getPos(), 0.6f, 1.0f);
        remove(e);
    }

    private static void remove(Entity e) {
        SESSIONS.remove(e.getUuid());
        OBSERVED.remove(e.getUuid());
        SPY_UNTIL.remove(e.getUuid());
        if (CampaignManager.state().watcherUuid.equals(e.getUuid().toString())) {
            CampaignManager.state().watcherUuid = "";
        }
        e.discard();
    }

    /** Olho de Vidro: faz o Watcher (se estiver por perto) ganhar contorno visivel por alguns segundos. */
    public static boolean revealNear(ServerPlayerEntity p, double radius, int glowTicks) {
        boolean found = false;
        for (UUID id : new ArrayList<>(SESSIONS.keySet())) {
            Entity en = p.getServerWorld().getEntity(id);
            if (en != null && en.distanceTo(p) <= radius) {
                en.setGlowing(true);
                found = true;
                DelayedTasks.scheduleAlways(glowTicks, p.getUuid(), "glass_eye", pl -> {
                    Entity again = pl.getServerWorld().getEntity(id);
                    if (again != null) again.setGlowing(false);
                });
            }
        }
        return found;
    }

    /** Remove todos os Watchers ativos (final, comando, parada do servidor). */
    public static int discardAll(MinecraftServer server) {
        int n = 0;
        List<UUID> ids = new ArrayList<>(SESSIONS.keySet());
        SESSIONS.clear();
        OBSERVED.clear();
        SPY_UNTIL.clear();
        for (ServerWorld w : server.getWorlds()) {
            for (UUID id : ids) {
                Entity e = w.getEntity(id);
                if (e != null) { e.discard(); n++; }
            }
        }
        CampaignManager.state().watcherUuid = "";
        return n;
    }
}
