package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.audio.Audio;
import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.entity.ModEntities;
import com.leonardo.somethingiswrong.entity.WatcherEntity;
import com.leonardo.somethingiswrong.observation.ObservationMath;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Ciclo de vida do Watcher. No maximo UMA entidade ativa por vez. Cada entidade pertence a uma sessao;
 * entidades sem sessao (ex.: restauradas do disco) sao descartadas pelo proprio tick.
 */
public final class WatcherManager {
    /** vanishOnLook: some ao ser observado. stalk: se aproxima devagar enquanto nao e observado. */
    public record Session(UUID target, int maxAge, int grace, boolean vanishOnLook, boolean stalk) {}

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static final double HALF_ANGLE = 28.0;
    private static final int CHECK_INTERVAL = 5; // observacao a cada 5 ticks, nao a cada quadro

    private WatcherManager() {}

    public static boolean isPresent() { return !SESSIONS.isEmpty(); }

    public static boolean spawn(ServerWorld w, ServerPlayerEntity target, Vec3d pos, Session s) {
        if (isPresent()) return false; // nunca duplica
        WatcherEntity e = ModEntities.THE_WATCHER.create(w);
        if (e == null) return false;
        float yaw = yawToward(pos, target.getPos());
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, 0f);
        e.setHeadYaw(yaw);
        e.setBodyYaw(yaw);
        SESSIONS.put(e.getUuid(), s);
        if (!w.spawnEntity(e)) {
            SESSIONS.remove(e.getUuid());
            return false;
        }
        CampaignManager.state().watcherUuid = e.getUuid().toString();
        return true;
    }

    private static float yawToward(Vec3d from, Vec3d to) {
        return (float) (MathHelper.atan2(to.z - from.z, to.x - from.x) * 180.0 / Math.PI) - 90.0f;
    }

    public static void onWatcherTick(WatcherEntity e) {
        Session s = SESSIONS.get(e.getUuid());
        if (s == null) { e.discard(); return; }
        if (!(e.getWorld() instanceof ServerWorld w)) return;
        MinecraftServer server = w.getServer();
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(s.target());
        if (p == null || p.isSpectator() || p.getServerWorld() != w || !p.isAlive()) { remove(e); return; }

        // olha sempre para o jogador
        float yaw = yawToward(e.getPos(), p.getPos());
        e.setYaw(yaw);
        e.setHeadYaw(yaw);
        e.setBodyYaw(yaw);

        if (e.age >= s.maxAge()) { fade(w, p, e); return; }
        if (e.age % CHECK_INTERVAL != 0) return;

        ModSettings cfg = ConfigManager.get();
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d t = e.getEyePos();
        ObservationMath.View view = ObservationMath.classify(eye.x, eye.y, eye.z, look.x, look.y, look.z,
                t.x, t.y, t.z, cfg.observationMinDistance, cfg.observationMaxDistance, HALF_ANGLE);
        boolean observed = view == ObservationMath.View.IN_VIEW && SpawnFinder.clearLine(w, p, t);

        if (observed && s.vanishOnLook() && e.age >= s.grace()) {
            CampaignManager.onWatcherSeen(p);
            fade(w, p, e);
            return;
        }
        if (!observed && s.stalk() && e.age % 20 == 0) stalkStep(w, p, e);
        if (e.age % 100 == 50) Audio.mod(p, ModSounds.WATCHER_AMBIENT, e.getPos(), 0.35f, 1.0f);
        // batimento cardiaco que aumenta conforme ele se aproxima
        if (e.age % 40 == 0) {
            double d = e.distanceTo(p);
            if (d < 18.0) Audio.mod(p, ModSounds.HEARTBEAT, p.getPos(), (float) (0.15 + 0.85 * (1.0 - d / 18.0)), 1.0f);
        }
    }

    private static void stalkStep(ServerWorld w, ServerPlayerEntity p, WatcherEntity e) {
        Vec3d to = p.getPos().subtract(e.getPos());
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        if (flat < 8.0 || Math.abs(to.y) > 3.0) return;
        Vec3d step = new Vec3d(to.x / flat, 0, to.z / flat);
        Vec3d np = e.getPos().add(step);
        net.minecraft.util.math.BlockPos feet = net.minecraft.util.math.BlockPos.ofFloored(np);
        if (w.getBlockState(feet).isAir() && w.getBlockState(feet.up()).isAir()
                && w.getBlockState(feet.down()).isSolidBlock(w, feet.down())) {
            e.refreshPositionAndAngles(np.x, e.getY(), np.z, e.getYaw(), 0f);
        }
    }

    /** Desaparecimento controlado: fumaca, som, sem drops, sem XP, sem vestigios. */
    private static void fade(ServerWorld w, ServerPlayerEntity p, WatcherEntity e) {
        w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1.0, e.getZ(), 14, 0.25, 0.7, 0.25, 0.01);
        Audio.mod(p, ModSounds.WATCHER_VANISH, e.getPos(), 0.6f, 1.0f);
        remove(e);
    }

    private static void remove(Entity e) {
        SESSIONS.remove(e.getUuid());
        if (CampaignManager.state().watcherUuid.equals(e.getUuid().toString())) {
            CampaignManager.state().watcherUuid = "";
        }
        e.discard();
    }

    /** Remove todos os Watchers ativos (final, comando, parada do servidor). */
    public static int discardAll(MinecraftServer server) {
        int n = 0;
        List<UUID> ids = new ArrayList<>(SESSIONS.keySet());
        SESSIONS.clear();
        for (ServerWorld w : server.getWorlds()) {
            for (UUID id : ids) {
                Entity e = w.getEntity(id);
                if (e != null) { e.discard(); n++; }
            }
        }
        CampaignManager.state().watcherUuid = "";
        return n;
    }
}
