package com.leonardo.somethingiswrong.item;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

/** Itens do mod: sem combate, sem alterar o mundo. */
public final class ModItems {
    public static final Item TORN_DIARY = register("torn_diary", new TornDiaryItem(new Item.Settings().maxCount(1)));
    public static final Item GLASS_EYE = register("glass_eye", new GlassEyeItem(new Item.Settings().maxCount(1)));
    /** Segurado no inventario: reduz o ganho de medo e acelera a queda dele (sem efeito visivel). */
    public static final Item SILENCE_CHARM = register("silence_charm", new Item(new Item.Settings().maxCount(1)));

    private ModItems() {}

    private static Item register(String id, Item item) {
        return Registry.register(Registries.ITEM, SomethingIsWrongMod.id(id), item);
    }

    public static void register() {
        Registry.register(Registries.ITEM_GROUP, SomethingIsWrongMod.id("main"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(GLASS_EYE))
                .displayName(Text.translatable("itemGroup.somethingiswrong"))
                .entries((context, entries) -> {
                    entries.add(TORN_DIARY);
                    entries.add(GLASS_EYE);
                    entries.add(SILENCE_CHARM);
                }).build());
    }
}
