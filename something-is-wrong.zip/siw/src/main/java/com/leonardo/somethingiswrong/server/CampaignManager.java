package com.leonardo.somethingiswrong.server;

import com.leonardo.somethingiswrong.SomethingIsWrongMod;
import com.leonardo.somethingiswrong.anomaly.AnomalyDefinition;
import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.anomaly.AnomalyScheduler;
import com.leonardo.somethingiswrong.anomaly.BehaviorTracker;
import com.leonardo.somethingiswrong.anomaly.SafetyContext;
import com.leonardo.somethingiswrong.audio.Audio;
import com.leonardo.somethingiswrong.audio.ModSounds;
import com.leonardo.somethingiswrong.audio.Narration;
import com.leonardo.somethingiswrong.campaign.*;
import com.leonardo.somethingiswrong.config.ConfigManager;
import com.leonardo.somethingiswrong.config.ModSettings;
import com.leonardo.somethingiswrong.item.ModItems;
import com.leonardo.somethingiswrong.net.ModNetworking;
import com.leonardo.somethingiswrong.persistence.CampaignPersistentState;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/**
 * Orquestrador do servidor: relogio da campanha (em ticks do jogo), sorteio de anomalias,
 * execucao do final e ponte com a persistencia. O relogio so avanca quando ha jogadores ativos.
 */
public final class CampaignManager {
    private static final int LOG_MAX = 64;

    private static CampaignPersistentState persistent;
    private static MinecraftServer server;
    private static final CampaignState FALLBACK = new CampaignState();
    private static final Random RANDOM = new Random();
    private static final Map<UUID, BehaviorTracker> TRACKERS = new HashMap<>();
    private static final Map<UUID, Vec3d> LAST_POS = new HashMap<>();
    private static final Map<UUID, Integer> STILL_SECONDS = new HashMap<>();
    private static final Deque<String> LOG = new ArrayDeque<>();
    private static long tickCounter = 0;
    private static long lastWaitLog = 0;

    private CampaignManager() {}

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(CampaignManager::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPING.register(CampaignManager::onServerStopping);
        ServerTickEvents.END_SERVER_TICK.register(CampaignManager::onTick);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, srv) -> onJoin(handler.getPlayer()));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, srv) -> onDisconnect(handler.getPlayer()));
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> onChat(sender, message.getSignedContent()));
        EntitySleepEvents.STOP_SLEEPING.register((entity, sleepingPos) -> {
            if (entity instanceof ServerPlayerEntity sp) onWake(sp);
        });
    }

    // ---------- acesso ----------

    public static CampaignState state() { return persistent != null ? persistent.state : FALLBACK; }

    public static boolean isLoaded() { return persistent != null; }

    public static BehaviorTracker trackerFor(ServerPlayerEntity p) {
        return TRACKERS.computeIfAbsent(p.getUuid(), k -> new BehaviorTracker());
    }

    public static void onWatcherSeen(ServerPlayerEntity p) {
        trackerFor(p).noteWatcherLook();
        CampaignState st = state();
        st.watcherLooks++;
        FearModel.add(st, FearModel.GAIN_WATCHER_SEEN, anyCharm(activePlayers()));
        if (st.watcherLooks == 1) Achievements.grant(p, AchievementIds.DONT_BLINK);
        if (st.watcherLooks >= 5) Achievements.grant(p, AchievementIds.KEEP_LOOKING);
        dirty();
        debugLog("Watcher observado por " + p.getName().getString() + " (total " + st.watcherLooks + ")");
    }

    public static List<String> recentLog() { return new ArrayList<>(LOG); }

    public static void debugLog(String line) {
        String entry = "[t=" + state().elapsedTicks + " " + state().phase.name() + "] " + line;
        LOG.addLast(entry);
        while (LOG.size() > LOG_MAX) LOG.removeFirst();
        if (ConfigManager.get().debug) SomethingIsWrongMod.LOGGER.info("[debug] {}", entry);
    }

    private static void dirty() { if (persistent != null) persistent.markDirty(); }

    // ---------- ciclo de vida ----------

    private static void onServerStarted(MinecraftServer srv) {
        server = srv;
        persistent = CampaignPersistentState.get(srv);
        ModSettings cfg = ConfigManager.get();
        if (cfg.resetCampaignOnNextStart) {
            persistent.state.reset();
            cfg.resetCampaignOnNextStart = false;
            ConfigManager.save();
            SomethingIsWrongMod.LOGGER.info("Campanha reiniciada por pedido explicito na configuracao (o mundo nao foi tocado).");
        }
        persistent.state.validate(cfg.campaignMinutes);
        persistent.markDirty();
        DelayedTasks.clear();
        TRACKERS.clear();
        debugLog("servidor iniciado; estado carregado");
    }

    private static void onServerStopping(MinecraftServer srv) {
        if (persistent != null) {
            WatcherManager.discardAll(srv);
            persistent.markDirty();
        }
        DelayedTasks.clear();
        persistent = null;
        server = null;
    }

    private static void onJoin(ServerPlayerEntity p) {
        ModSettings cfg = ConfigManager.get();
        if (persistent == null || !cfg.enabled) return;
        CampaignState st = state();
        if (!st.started && cfg.autoStart) {
            startCampaign();
        }
    }

    // ---------- medo, amuleto, chat ----------

    public static void addFear(int amount) {
        FearModel.add(state(), amount, anyCharm(activePlayers()));
    }

    private static boolean holdsCharm(ServerPlayerEntity p) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            if (p.getInventory().getStack(i).isOf(ModItems.SILENCE_CHARM)) return true;
        }
        return false;
    }

    private static boolean anyCharm(List<ServerPlayerEntity> players) {
        for (ServerPlayerEntity p : players) if (holdsCharm(p)) return true;
        return false;
    }

    private static boolean blockedDimension(ServerPlayerEntity p) {
        return ConfigManager.get().blockedDimensions.contains(p.getServerWorld().getRegistryKey().getValue().toString());
    }

    private static long lastChatReply = -100000;

    private static void onChat(ServerPlayerEntity sender, String text) {
        ModSettings cfg = ConfigManager.get();
        CampaignState st = state();
        if (persistent == null || server == null || !cfg.enabled || !cfg.chatResponses || !st.started) return;
        if (st.climax != ClimaxStatus.NOT_STARTED || st.phase.ordinal() < Phase.SOMETHING_WRONG.ordinal()) return;
        String key = ChatTriggers.match(text);
        if (key == null) return;
        server.execute(() -> {
            long now = server.getTicks();
            if (now - lastChatReply < 1200) return; // no maximo uma resposta por minuto
            lastChatReply = now;
            DelayedTasks.schedule(50, sender.getUuid(), "chat_reply", pl -> {
                Narration.say(pl, key);
                CampaignState s2 = state();
                s2.chatReplies++;
                Achievements.grant(pl, AchievementIds.ANSWERED);
                if (ChatTriggers.SECRET.equals(key)) Achievements.grant(pl, AchievementIds.SECRET_CODE);
                if (s2.chatReplies >= EndingVariant.REPLIES_THRESHOLD) Achievements.grant(pl, AchievementIds.CONVERSED);
                FearModel.add(s2, FearModel.GAIN_CHAT, holdsCharm(pl));
                dirty();
                debugLog("chat respondido: " + key);
            });
        });
    }

    private static long lastSleepNarration = -100000;

    private static void onWake(ServerPlayerEntity p) {
        ModSettings cfg = ConfigManager.get();
        CampaignState st = state();
        if (persistent == null || !cfg.enabled || !st.started || st.climax != ClimaxStatus.NOT_STARTED) return;
        if (st.phase.ordinal() < Phase.SOMETHING_WRONG.ordinal()) return;
        Achievements.grant(p, AchievementIds.INSOMNIA);
        if (st.elapsedTicks - lastSleepNarration >= 3600) {
            lastSleepNarration = st.elapsedTicks;
            DelayedTasks.schedule(60, p.getUuid(), "wake_narration", pl -> Narration.say(pl, "r_sleep"));
        }
    }

    private static void onDisconnect(ServerPlayerEntity p) {
        TRACKERS.remove(p.getUuid());
        LAST_POS.remove(p.getUuid());
        STILL_SECONDS.remove(p.getUuid());
    }

    // ---------- acoes publicas (usadas tambem pelos comandos) ----------

    public static boolean startCampaign() {
        CampaignState st = state();
        if (persistent == null || st.started) return false;
        st.start();
        st.validate(ConfigManager.get().campaignMinutes);
        dirty();
        debugLog("campanha iniciada " + st.campaignId);
        return true;
    }

    public static void resetCampaign() {
        if (server != null) {
            WatcherManager.discardAll(server);
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) clearClimaxEffects(p);
        }
        DelayedTasks.clear();
        state().reset();
        dirty();
        debugLog("campanha reiniciada (mundo intacto)");
    }

    public static void nextPhase() {
        CampaignClock.jumpToNextPhase(state(), ConfigManager.get());
        dirty();
        debugLog("fase avancada manualmente");
    }

    public static boolean forceTrigger(String id, ServerPlayerEntity p) {
        if (AnomalyRegistry.FINALE.equals(id)) return forceFinale(p);
        AnomalyDefinition def = AnomalyRegistry.get(id);
        if (def == null) return false;
        return execute(def, p, true);
    }

    public static boolean forceFinale(ServerPlayerEntity p) {
        if (persistent == null) return false;
        CampaignState st = state();
        if (!st.started) startCampaign();
        if (st.climax != ClimaxStatus.NOT_STARTED) return false;
        beginClimax(activePlayers());
        return true;
    }

    // ---------- tick ----------

    private static List<ServerPlayerEntity> activePlayers() {
        List<ServerPlayerEntity> out = new ArrayList<>();
        if (server == null) return out;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isSpectator() && p.isAlive()) out.add(p);
        }
        return out;
    }

    private static void onTick(MinecraftServer srv) {
        DelayedTasks.tick(srv);
        ModSettings cfg = ConfigManager.get();
        if (persistent == null || !cfg.enabled) return;
        CampaignState st = state();
        if (!st.started) return;
        List<ServerPlayerEntity> players = activePlayers();
        if (players.isEmpty()) return; // sem jogadores, o relogio fica parado
        tickCounter++;

        CampaignClock.syncLength(st, cfg.campaignMinutes);
        if (st.climax == ClimaxStatus.FINISHED) {
            if (cfg.epilogue) epilogueTick(players, cfg);
            return;
        }
        if (st.climax == ClimaxStatus.RUNNING) {
            applySteps(ClimaxRunner.advance(st), players);
            if (st.climaxTicks % 200 == 0 || st.climax == ClimaxStatus.FINISHED) dirty();
            return;
        }

        Optional<Phase> changed = CampaignClock.advance(st, cfg, 1);
        if (changed.isPresent()) {
            debugLog("fase -> " + changed.get().name());
            if (changed.get() == Phase.ENTITY) {
                for (ServerPlayerEntity pl : players) Achievements.grant(pl, AchievementIds.THE_WATCHER);
            }
            dirty();
        }
        FearModel.tick(st, anyCharm(players));
        if (tickCounter % 20 == 0) sampleBehavior(players);
        if (tickCounter % 600 == 0) dirty();

        if (CampaignClock.finaleDue(st, cfg)) {
            tryStartFinale(players);
            return;
        }
        if (st.elapsedTicks % AnomalyScheduler.ATTEMPT_INTERVAL_TICKS == 0) {
            attemptAnomaly(players);
        }
    }

    private static void sampleBehavior(List<ServerPlayerEntity> players) {
        for (ServerPlayerEntity p : players) {
            Vec3d pos = p.getPos();
            Vec3d last = LAST_POS.put(p.getUuid(), pos);
            int still = STILL_SECONDS.getOrDefault(p.getUuid(), 0);
            still = (last != null && last.squaredDistanceTo(pos) < 0.25) ? still + 1 : 0;
            STILL_SECONDS.put(p.getUuid(), still);
            boolean underground = !p.getServerWorld().isSkyVisible(p.getBlockPos());
            trackerFor(p).sample(still >= 10, underground);
        }
    }

    /** Depois do final: de tempos em tempos (~5 min), um evento raro e discreto. Nao registra contagens. */
    private static void epilogueTick(List<ServerPlayerEntity> players, ModSettings cfg) {
        long interval = Math.max(1200, Math.round(6000.0 / cfg.eventFrequency));
        if (tickCounter % interval != 0 || RANDOM.nextDouble() > 0.6) return;
        List<ServerPlayerEntity> candidates = new ArrayList<>();
        for (ServerPlayerEntity pl : players) if (!blockedDimension(pl)) candidates.add(pl);
        if (candidates.isEmpty()) return;
        ServerPlayerEntity target = candidates.get(RANDOM.nextInt(candidates.size()));
        List<AnomalyDefinition> options = AnomalyScheduler.epilogueCandidates(cfg, ContextBuilder.build(target));
        if (options.isEmpty()) return;
        AnomalyDefinition def = options.get(RANDOM.nextInt(options.size()));
        execute(def, target, true);
    }

    private static void attemptAnomaly(List<ServerPlayerEntity> players) {
        List<ServerPlayerEntity> candidates = new ArrayList<>();
        for (ServerPlayerEntity pl : players) if (!blockedDimension(pl)) candidates.add(pl);
        if (candidates.isEmpty()) return;
        ServerPlayerEntity target = candidates.get(RANDOM.nextInt(candidates.size()));
        SafetyContext ctx = ContextBuilder.build(target);
        Optional<AnomalyDefinition> pick = AnomalyScheduler.select(AnomalyRegistry.all(), state(), ConfigManager.get(),
                ctx, state().elapsedTicks, RANDOM);
        pick.ifPresent(def -> execute(def, target, false));
    }

    private static boolean execute(AnomalyDefinition def, ServerPlayerEntity p, boolean forced) {
        AnomalyActions.Action action = AnomalyActions.get(def.id);
        if (action == null) return false;
        boolean ok;
        try {
            ok = action.run(new ActionEnv(server, p.getServerWorld(), p, state(), ConfigManager.get(), RANDOM));
        } catch (Exception e) {
            SomethingIsWrongMod.LOGGER.warn("Anomalia {} falhou: {}", def.id, e.toString());
            ok = false;
        }
        if (ok) {
            if (!forced) {
                AnomalyScheduler.record(state(), def, state().elapsedTicks);
                FearModel.add(state(), FearModel.GAIN_ANOMALY, holdsCharm(p));
                Achievements.grant(p, AchievementIds.FIRST_SIGN);
                if (AnomalyRegistry.FOOTSTEPS.equals(def.id) || AnomalyRegistry.STEPS_CIRCLE.equals(def.id) || AnomalyRegistry.MIMIC.equals(def.id)) {
                    Achievements.grant(p, AchievementIds.ECHO);
                }
                dirty();
            }
            debugLog(def.id + " -> " + p.getName().getString() + (forced ? " (forcado, nao registrado)" : ""));
        } else {
            debugLog(def.id + " nao pode executar agora (sem posicao/som disponivel)");
        }
        return ok;
    }

    // ---------- final ----------

    private static void tryStartFinale(List<ServerPlayerEntity> players) {
        ServerPlayerEntity primary = players.get(0);
        SafetyContext ctx = ContextBuilder.build(primary);
        if (!ctx.isSafeForEvents()) {
            if (tickCounter - lastWaitLog > 600) {
                lastWaitLog = tickCounter;
                debugLog("final adiado: jogador em situacao insegura");
            }
            return;
        }
        beginClimax(players);
    }

    private static void beginClimax(List<ServerPlayerEntity> players) {
        CampaignState st = state();
        List<ClimaxTimeline.Step> first = ClimaxRunner.start(st);
        if (first.isEmpty()) return;
        AnomalyScheduler.record(st, AnomalyRegistry.get(AnomalyRegistry.FINALE), st.elapsedTicks);
        debugLog("final iniciado");
        dirty();
        applySteps(first, players);
    }

    private static void applySteps(List<ClimaxTimeline.Step> steps, List<ServerPlayerEntity> players) {
        ModSettings cfg = ConfigManager.get();
        for (ClimaxTimeline.Step s : steps) {
            switch (s.action()) {
                case FINAL_MESSAGE -> {
                    for (ServerPlayerEntity p : players) {
                        p.sendMessage(Text.translatable("message.somethingiswrong.final").formatted(Formatting.GRAY, Formatting.ITALIC), false);
                        Narration.say(p, "r_final", false);
                    }
                }
                case SLOWNESS -> {
                    for (ServerPlayerEntity p : players) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,
                                ClimaxTimeline.clampDuration(s.a(), false), ClimaxTimeline.clampAmplifier(s.b()), true, false, false));
                    }
                }
                case BLINDNESS -> {
                    for (ServerPlayerEntity p : players) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,
                                ClimaxTimeline.clampDuration(s.a(), true), 0, true, false, false));
                    }
                }
                case SPAWN_WATCHER_NEAR -> spawnClimaxWatcher(players.get(0));
                case INTERFERENCE -> {
                    if (cfg.visualInterference) {
                        int intensity = (int) Math.min(100, s.a() * (0.5 + cfg.intensity / 100.0));
                        for (ServerPlayerEntity p : players) ModNetworking.sendInterference(p, s.b(), intensity);
                    }
                }
                case SOUND_PEAK -> {
                    for (ServerPlayerEntity p : players) {
                        Audio.mod(p, ModSounds.DRONE, p.getPos(), 1.0f, 0.8f);
                        Audio.mod(p, ModSounds.STATIC, p.getPos(), 0.5f, 0.9f);
                    }
                }
                case HEARTBEAT -> {
                    for (ServerPlayerEntity p : players) Audio.mod(p, ModSounds.HEARTBEAT, p.getPos(), 1.0f, 1.0f);
                }
                case NARRATE_LORE -> {
                    CampaignState st = state();
                    st.loreMask = LoreSchedule.mark(st.loreMask, LoreSchedule.FINAL_FRAGMENT);
                    for (ServerPlayerEntity p : players) {
                        Narration.say(p, LoreSchedule.key(LoreSchedule.FINAL_FRAGMENT));
                        if (st.loreMask == LoreSchedule.ALL_MASK) Achievements.grant(p, AchievementIds.DIARY_FULL);
                    }
                    dirty();
                }
                case ENDING_SCREEN -> {
                    int variant = EndingVariant.choose(state().watcherLooks, state().chatReplies);
                    for (ServerPlayerEntity p : players) ModNetworking.sendEnding(p, variant);
                }
                case FINISH -> finishClimax(players);
            }
        }
    }

    private static void spawnClimaxWatcher(ServerPlayerEntity p) {
        WatcherManager.discardAll(server);
        Optional<Vec3d> pos = SpawnFinder.find(p.getServerWorld(), p, SpawnFinder.Placement.FRONT, 9, 13, false, RANDOM);
        if (pos.isEmpty()) pos = SpawnFinder.find(p.getServerWorld(), p, SpawnFinder.Placement.ANY, 8, 14, false, RANDOM);
        pos.ifPresent(v -> WatcherManager.spawn(p.getServerWorld(), p, v,
                new WatcherManager.Session(p.getUuid(), ClimaxTimeline.WATCHER_LIFETIME, 0, false, false)));
    }

    private static void finishClimax(List<ServerPlayerEntity> players) {
        WatcherManager.discardAll(server);
        int variant = EndingVariant.choose(state().watcherLooks, state().chatReplies);
        for (ServerPlayerEntity p : players) {
            clearClimaxEffects(p);
            Achievements.grant(p, AchievementIds.I_SAW_YOU);
            Achievements.grant(p, variant == EndingVariant.LOOKED ? AchievementIds.NEVER_ALONE
                    : variant == EndingVariant.CONVERSED ? AchievementIds.CONVERSED : AchievementIds.IGNORED);
        }
        debugLog("final concluido (variante " + variant + ")");
        dirty();
    }

    private static void clearClimaxEffects(ServerPlayerEntity p) {
        p.removeStatusEffect(StatusEffects.SLOWNESS);
        p.removeStatusEffect(StatusEffects.BLINDNESS);
    }
}
