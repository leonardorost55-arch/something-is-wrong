package com.leonardo.somethingiswrong.anomaly;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Catalogo das 10 anomalias. Janelas em segundos base (20 min = 1200 s). */
public final class AnomalyRegistry {
    public static final String FOOTSTEPS = "footsteps_unseen";
    public static final String SILHOUETTE = "distant_silhouette";
    public static final String ODD_SOUND = "odd_direction_sound";
    public static final String LONE_MESSAGE = "lone_message";
    public static final String WATCHER_FLICKER = "watcher_flicker";
    public static final String WATCHER_VANISH = "watcher_vanish_on_look";
    public static final String CLOSE_NOISE = "close_ambient_noise";
    public static final String INTERFERENCE = "visual_interference";
    public static final String ADAPTIVE = "behavior_adaptive";
    public static final String FINALE = "final_sequence";
    public static final String DIARY = "narration_diary";
    public static final String TORCH_HISS = "torch_hiss";
    public static final String DOOR_PHANTOM = "door_phantom";
    public static final String KNOCK = "knock_unseen";
    public static final String ANIMALS_STARE = "animals_stare";
    public static final String DARKNESS = "darkness_pulse";
    public static final String STEPS_CIRCLE = "footsteps_circle";
    public static final String TREELINE = "watcher_treeline";
    public static final String TUNNEL = "watcher_tunnel";
    public static final String MUSIC_BOX = "music_box_far";
    public static final String HEARTBEAT = "heartbeat_rise";
    public static final String BEHIND_CLOSE = "watcher_behind_close";
    public static final String ILLUSION_PILLAR = "illusion_pillar";
    public static final String ASH_FALL = "ash_fall";
    public static final String MIMIC = "mimic_echo";
    private static final int FINALE_SECONDS = 1200;

    private static final Map<String, AnomalyDefinition> BY_ID = new LinkedHashMap<>();

    static {
        add(AnomalyDefinition.of(FOOTSTEPS, 360, 1020, 5, 0.60, 100, 5));
        add(AnomalyDefinition.of(SILHOUETTE, 360, 1080, 3, 0.50, 150, 4, Requirement.OUTDOORS));
        add(AnomalyDefinition.of(ODD_SOUND, 180, 1080, 5, 0.60, 70, 8));
        add(AnomalyDefinition.of(LONE_MESSAGE, 270, 1080, 3, 0.50, 150, 6));
        add(AnomalyDefinition.of(WATCHER_FLICKER, 540, 1080, 3, 0.45, 120, 6, Requirement.NO_WATCHER));
        add(AnomalyDefinition.of(WATCHER_VANISH, 720, 1080, 6, 0.70, 90, 6, Requirement.NO_WATCHER).withMustRunOnce());
        add(AnomalyDefinition.of(CLOSE_NOISE, 180, 1080, 4, 0.50, 80, 8));
        add(AnomalyDefinition.of(INTERFERENCE, 540, 1080, 2, 0.40, 240, 4).withNeedsVisual());
        add(AnomalyDefinition.of(ADAPTIVE, 360, 1080, 3, 0.50, 120, 6));
        add(AnomalyDefinition.of(DIARY, 200, 1080, 4, 0.70, 55, 7));
        add(AnomalyDefinition.of(TORCH_HISS, 270, 1020, 3, 0.50, 120, 4));
        add(AnomalyDefinition.of(DOOR_PHANTOM, 240, 1020, 3, 0.50, 100, 5));
        add(AnomalyDefinition.of(KNOCK, 360, 1080, 3, 0.50, 120, 4));
        add(AnomalyDefinition.of(ANIMALS_STARE, 420, 1020, 2, 0.50, 200, 3, Requirement.OUTDOORS));
        add(AnomalyDefinition.of(DARKNESS, 540, 1080, 2, 0.40, 180, 4).withNeedsVisual());
        add(AnomalyDefinition.of(STEPS_CIRCLE, 540, 1080, 3, 0.50, 150, 3));
        add(AnomalyDefinition.of(TREELINE, 540, 1080, 3, 0.45, 140, 5, Requirement.NO_WATCHER, Requirement.OUTDOORS));
        add(AnomalyDefinition.of(TUNNEL, 540, 1080, 4, 0.55, 140, 5, Requirement.NO_WATCHER, Requirement.UNDERGROUND));
        add(AnomalyDefinition.of(MUSIC_BOX, 450, 1080, 2, 0.40, 240, 3));
        add(AnomalyDefinition.of(HEARTBEAT, 900, 1080, 3, 0.60, 100, 5));
        add(AnomalyDefinition.of(BEHIND_CLOSE, 900, 1080, 2, 0.40, 200, 3, Requirement.NO_WATCHER));
        add(AnomalyDefinition.of(ILLUSION_PILLAR, 540, 1080, 2, 0.40, 180, 4, Requirement.OUTDOORS).withNeedsVisual());
        add(AnomalyDefinition.of(ASH_FALL, 360, 1080, 2, 0.40, 150, 4, Requirement.OUTDOORS).withNeedsVisual());
        add(AnomalyDefinition.of(MIMIC, 450, 1080, 3, 0.50, 120, 5));
        add(AnomalyDefinition.scripted(FINALE, FINALE_SECONDS));
    }

    

    private AnomalyRegistry() {}

    private static void add(AnomalyDefinition d) { BY_ID.put(d.id, d); }

    public static List<AnomalyDefinition> all() { return new ArrayList<>(BY_ID.values()); }

    public static AnomalyDefinition get(String id) { return BY_ID.get(id); }

    public static List<String> ids() { return new ArrayList<>(BY_ID.keySet()); }
}
