package com.leonardo.somethingiswrong.anomaly;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Catalogo das 10 anomalias. Janelas em segundos base (20 min = 1200 s). */
public final class AnomalyRegistry {
    public static final String FOOTSTEPS = "footsteps_unseen";
    public static final String SILHOUETTE = "distant_silhouette";
    public static final String ODD_SOUND = "odd_direction_sound";
    public static final String LONE_MESSAGE = "lone_message";
    public static final String WATCHER_FLICKER = "watcher_flicker";
    public static final String WATCHER_VANISH = "watcher_vanish_on_look";
    public static final String CLOSE_NOISE = "close_ambient_noise";
    public static final String INTERFERENCE = "visual_interference";
    public static final String ADAPTIVE = "behavior_adaptive";
    public static final String FINALE = "final_sequence";
    private static final int FINALE_SECONDS = 1200;

    private static final Map<String, AnomalyDefinition> BY_ID = new LinkedHashMap<>();

    static {
        add(AnomalyDefinition.of(FOOTSTEPS, 360, 1020, 5, 0.60, 100, 5));
        add(AnomalyDefinition.of(SILHOUETTE, 360, 1080, 3, 0.50, 150, 4, Requirement.OUTDOORS));
        add(AnomalyDefinition.of(ODD_SOUND, 180, 1080, 5, 0.60, 70, 8));
        add(AnomalyDefinition.of(LONE_MESSAGE, 270, 1080, 3, 0.50, 150, 6));
        add(AnomalyDefinition.of(WATCHER_FLICKER, 540, 1080, 3, 0.45, 120, 6, Requirement.NO_WATCHER));
        add(AnomalyDefinition.of(WATCHER_VANISH, 720, 1080, 6, 0.70, 90, 6, Requirement.NO_WATCHER).withMustRunOnce());
        add(AnomalyDefinition.of(CLOSE_NOISE, 180, 1080, 4, 0.50, 80, 8));
        add(AnomalyDefinition.of(INTERFERENCE, 540, 1080, 2, 0.40, 240, 4).withNeedsVisual());
        add(AnomalyDefinition.of(ADAPTIVE, 360, 1080, 3, 0.50, 120, 6));
        add(AnomalyDefinition.scripted(FINALE, FINALE_SECONDS));
    }

    

    private AnomalyRegistry() {}

    private static void add(AnomalyDefinition d) { BY_ID.put(d.id, d); }

    public static List<AnomalyDefinition> all() { return new ArrayList<>(BY_ID.values()); }

    public static AnomalyDefinition get(String id) { return BY_ID.get(id); }

    public static List<String> ids() { return new ArrayList<>(BY_ID.keySet()); }
}
