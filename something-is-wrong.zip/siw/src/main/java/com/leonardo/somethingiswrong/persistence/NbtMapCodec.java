package com.leonardo.somethingiswrong.persistence;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;

import java.util.LinkedHashMap;
import java.util.Map;

/** Converte o Map generico do CampaignState de/para NbtCompound. */
public final class NbtMapCodec {
    private NbtMapCodec() {}

    public static NbtCompound toNbt(Map<String, Object> map) {
        NbtCompound c = new NbtCompound();
        for (Map.Entry<String, Object> e : map.entrySet()) {
            Object v = e.getValue();
            String k = e.getKey();
            if (v instanceof String s) c.putString(k, s);
            else if (v instanceof Integer i) c.putInt(k, i);
            else if (v instanceof Long l) c.putLong(k, l);
            else if (v instanceof Boolean b) c.putBoolean(k, b);
            else if (v instanceof Map<?, ?> m) {
                Map<String, Object> typed = new LinkedHashMap<>();
                for (Map.Entry<?, ?> me : m.entrySet()) typed.put(String.valueOf(me.getKey()), me.getValue());
                c.put(k, toNbt(typed));
            }
        }
        return c;
    }

    public static Map<String, Object> fromNbt(NbtCompound c) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (String k : c.getKeys()) {
            NbtElement e = c.get(k);
            if (e == null) continue;
            switch (e.getType()) {
                case NbtElement.STRING_TYPE -> m.put(k, c.getString(k));
                case NbtElement.INT_TYPE -> m.put(k, c.getInt(k));
                case NbtElement.LONG_TYPE -> m.put(k, c.getLong(k));
                case NbtElement.BYTE_TYPE -> m.put(k, c.getBoolean(k));
                case NbtElement.COMPOUND_TYPE -> m.put(k, fromNbt(c.getCompound(k)));
                default -> { /* tipos desconhecidos sao ignorados */ }
            }
        }
        return m;
    }
}
