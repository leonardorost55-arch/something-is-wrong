package com.leonardo.somethingiswrong;

import com.leonardo.somethingiswrong.anomaly.AnomalyDefinition;
import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.campaign.*;
import com.leonardo.somethingiswrong.config.ModSettings;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Lore, conquistas, narracao e novas anomalias. */
class ContentTest {

    private static boolean res(String path) {
        return ContentTest.class.getResource(path) != null;
    }

    @Test
    void loreFragmentsAreOrderedAndGatedByTime() {
        assertEquals(-1, LoreSchedule.next(0, 100));
        assertEquals(0, LoreSchedule.next(0, 200));
        // fragmento 2 so depois de 300 s e so depois do 1o
        assertEquals(-1, LoreSchedule.next(LoreSchedule.mark(0, 0), 250));
        assertEquals(1, LoreSchedule.next(LoreSchedule.mark(0, 0), 300));
        int mask = 0;
        for (int i = 0; i < LoreSchedule.DIARY_FRAGMENTS; i++) {
            assertEquals(i, LoreSchedule.next(mask, 1100));
            mask = LoreSchedule.mark(mask, i);
        }
        assertEquals(-1, LoreSchedule.next(mask, 1100));
        assertEquals(7, LoreSchedule.count(mask));
        assertEquals("lore_1", LoreSchedule.key(0));
        assertEquals("lore_8", LoreSchedule.key(7));
    }

    @Test
    void endingVariantFollowsBehaviour() {
        assertEquals(EndingVariant.IGNORED, EndingVariant.choose(0));
        assertEquals(EndingVariant.IGNORED, EndingVariant.choose(3));
        assertEquals(EndingVariant.LOOKED, EndingVariant.choose(4));
        assertEquals(EndingVariant.LOOKED, EndingVariant.choose(40));
    }

    @Test
    void loreAndLooksPersist() {
        CampaignState s = new CampaignState();
        s.start();
        s.loreMask = LoreSchedule.mark(LoreSchedule.mark(0, 0), 3);
        s.watcherLooks = 6;
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(20);
        assertEquals(s.loreMask, r.loreMask);
        assertEquals(6, r.watcherLooks);
        r.reset();
        assertEquals(0, r.loreMask);
        assertEquals(0, r.watcherLooks);
    }

    @Test
    void narrationLanguageIsValidated() {
        ModSettings c = new ModSettings();
        assertEquals("pt", c.narrationLanguage);
        c.narrationLanguage = " EN ";
        assertTrue(c.sanitize().isEmpty());
        assertEquals("en", c.narrationLanguage);
        c.narrationLanguage = "klingon";
        assertFalse(c.sanitize().isEmpty());
        assertEquals("pt", c.narrationLanguage);
        c.narrationLanguage = "off";
        c.sanitize();
        assertFalse(c.narrationVoiceEnabled());
        c.narrationLanguage = null;
        c.sanitize();
        assertEquals("pt", c.narrationLanguage);
    }

    @Test
    void registryHasAtLeastTwentyAnomalies() {
        assertTrue(AnomalyRegistry.ids().size() >= 22, "total=" + AnomalyRegistry.ids().size());
        for (AnomalyDefinition d : AnomalyRegistry.all()) {
            assertTrue(d.startBaseSeconds >= 0 && d.endBaseSeconds > d.startBaseSeconds, d.id);
            assertTrue(d.maxRepeats >= 1, d.id);
            if (!d.scripted) assertTrue(d.startBaseSeconds >= 180, "nada antes da fase 2: " + d.id);
            if (!d.scripted) assertTrue(d.baseChance > 0 && d.baseChance <= 1, d.id);
        }
    }

    @Test
    void achievementIdsAreUniqueAndHaveAdvancementFiles() {
        List<String> ids = AchievementIds.ALL;
        assertEquals(ids.size(), new HashSet<>(ids).size());
        for (String id : ids) {
            assertTrue(res("/data/somethingiswrong/advancement/" + id + ".json"), "falta advancement " + id);
        }
    }

    @Test
    void narrationFilesExistForBothLanguages() {
        String[] keys = {"lore_1", "lore_2", "lore_3", "lore_4", "lore_5", "lore_6", "lore_7", "lore_8",
                "r_still", "r_under", "r_look", "r_walk", "r_sleep", "r_close", "r_final"};
        for (String lang : new String[]{"pt", "en"}) {
            for (String k : keys) {
                assertTrue(res("/assets/somethingiswrong/sounds/narration/" + lang + "/" + k + ".ogg"), lang + "/" + k);
            }
        }
    }

    @Test
    void climaxHasHeartbeatsAndFinalNarrationBeforeTheEnd() {
        boolean narr = false;
        int beats = 0;
        for (ClimaxTimeline.Step s : ClimaxTimeline.all()) {
            if (s.action() == ClimaxTimeline.Action.NARRATE_LORE) { narr = true; assertTrue(s.tick() < ClimaxTimeline.END_TICK); }
            if (s.action() == ClimaxTimeline.Action.HEARTBEAT) beats++;
        }
        assertTrue(narr);
        assertTrue(beats >= 3);
    }
}
