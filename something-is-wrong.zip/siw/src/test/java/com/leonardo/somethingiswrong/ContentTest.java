package com.leonardo.somethingiswrong;

import com.leonardo.somethingiswrong.anomaly.AnomalyDefinition;
import com.leonardo.somethingiswrong.anomaly.AnomalyRegistry;
import com.leonardo.somethingiswrong.anomaly.AnomalyScheduler;
import com.leonardo.somethingiswrong.anomaly.SafetyContext;
import com.leonardo.somethingiswrong.campaign.*;
import com.leonardo.somethingiswrong.config.ModSettings;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Lore, conquistas, narracao e novas anomalias. */
class ContentTest {

    private static boolean res(String path) {
        return ContentTest.class.getResource(path) != null;
    }

    @Test
    void loreFragmentsAreOrderedAndGatedByTime() {
        assertEquals(-1, LoreSchedule.next(0, 100));
        assertEquals(0, LoreSchedule.next(0, 200));
        // fragmento 2 so depois de 300 s e so depois do 1o
        assertEquals(-1, LoreSchedule.next(LoreSchedule.mark(0, 0), 250));
        assertEquals(1, LoreSchedule.next(LoreSchedule.mark(0, 0), 300));
        int mask = 0;
        for (int i = 0; i < LoreSchedule.DIARY_FRAGMENTS; i++) {
            assertEquals(i, LoreSchedule.next(mask, 1100));
            mask = LoreSchedule.mark(mask, i);
        }
        assertEquals(-1, LoreSchedule.next(mask, 1100));
        assertEquals(7, LoreSchedule.count(mask));
        assertEquals("lore_1", LoreSchedule.key(0));
        assertEquals("lore_8", LoreSchedule.key(7));
    }

    @Test
    void endingVariantFollowsBehaviour() {
        assertEquals(EndingVariant.IGNORED, EndingVariant.choose(0, 0));
        assertEquals(EndingVariant.IGNORED, EndingVariant.choose(3, 2));
        assertEquals(EndingVariant.LOOKED, EndingVariant.choose(4, 0));
        assertEquals(EndingVariant.LOOKED, EndingVariant.choose(40, 2));
        assertEquals(EndingVariant.CONVERSED, EndingVariant.choose(0, 3));
        assertEquals(EndingVariant.CONVERSED, EndingVariant.choose(40, 5));
    }

    @Test
    void loreAndLooksPersist() {
        CampaignState s = new CampaignState();
        s.start();
        s.loreMask = LoreSchedule.mark(LoreSchedule.mark(0, 0), 3);
        s.watcherLooks = 6;
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(20);
        assertEquals(s.loreMask, r.loreMask);
        assertEquals(6, r.watcherLooks);
        r.reset();
        assertEquals(0, r.loreMask);
        assertEquals(0, r.watcherLooks);
    }

    @Test
    void narrationLanguageIsValidated() {
        ModSettings c = new ModSettings();
        assertEquals("pt", c.narrationLanguage);
        c.narrationLanguage = " EN ";
        assertTrue(c.sanitize().isEmpty());
        assertEquals("en", c.narrationLanguage);
        c.narrationLanguage = "klingon";
        assertFalse(c.sanitize().isEmpty());
        assertEquals("pt", c.narrationLanguage);
        c.narrationLanguage = "off";
        c.sanitize();
        assertFalse(c.narrationVoiceEnabled());
        c.narrationLanguage = null;
        c.sanitize();
        assertEquals("pt", c.narrationLanguage);
    }

    @Test
    void registryHasAtLeastTwentyAnomalies() {
        assertTrue(AnomalyRegistry.ids().size() >= 26, "total=" + AnomalyRegistry.ids().size());
        for (AnomalyDefinition d : AnomalyRegistry.all()) {
            assertTrue(d.startBaseSeconds >= 0 && d.endBaseSeconds > d.startBaseSeconds, d.id);
            assertTrue(d.maxRepeats >= 1, d.id);
            if (!d.scripted) assertTrue(d.startBaseSeconds >= 180, "nada antes da fase 2: " + d.id);
            if (!d.scripted) assertTrue(d.baseChance > 0 && d.baseChance <= 1, d.id);
        }
    }

    @Test
    void achievementIdsAreUniqueAndHaveAdvancementFiles() {
        List<String> ids = AchievementIds.ALL;
        assertEquals(ids.size(), new HashSet<>(ids).size());
        for (String id : ids) {
            assertTrue(res("/data/somethingiswrong/advancement/" + id + ".json"), "falta advancement " + id);
        }
    }

    @Test
    void narrationFilesExistForBothLanguages() {
        String[] keys = {"lore_1", "lore_2", "lore_3", "lore_4", "lore_5", "lore_6", "lore_7", "lore_8",
                "r_still", "r_under", "r_look", "r_walk", "r_sleep", "r_close", "r_final",
                "c_who", "c_help", "c_hello", "c_leave", "c_secret", "r_zoom"};
        for (String lang : new String[]{"pt", "en"}) {
            for (String k : keys) {
                assertTrue(res("/assets/somethingiswrong/sounds/narration/" + lang + "/" + k + ".ogg"), lang + "/" + k);
            }
        }
    }

    @Test
    void climaxHasHeartbeatsAndFinalNarrationBeforeTheEnd() {
        boolean narr = false;
        int beats = 0;
        for (ClimaxTimeline.Step s : ClimaxTimeline.all()) {
            if (s.action() == ClimaxTimeline.Action.NARRATE_LORE) { narr = true; assertTrue(s.tick() < ClimaxTimeline.END_TICK); }
            if (s.action() == ClimaxTimeline.Action.HEARTBEAT) beats++;
        }
        assertTrue(narr);
        assertTrue(beats >= 3);
    }

    @Test
    void watcherEvolutionGrowsMonotonically() {
        assertEquals(0, WatcherEvolution.stage(0));
        assertEquals(1, WatcherEvolution.stage(5));
        assertEquals(2, WatcherEvolution.stage(10));
        assertEquals(3, WatcherEvolution.stage(16));
        assertEquals(3, WatcherEvolution.stage(999));
        WatcherEvolution.Profile prev = WatcherEvolution.profile(0);
        for (int i = 1; i <= 3; i++) {
            WatcherEvolution.Profile cur = WatcherEvolution.profile(i);
            assertTrue(cur.graceTicks() >= prev.graceTicks());
            assertTrue(cur.stalkChance() >= prev.stalkChance());
            assertTrue(cur.stalkIntervalTicks() <= prev.stalkIntervalTicks());
            assertTrue(cur.minApproach() <= prev.minApproach());
            assertTrue(cur.minApproach() >= 4.0, "nunca encosta no jogador");
            prev = cur;
        }
        CampaignState s = new CampaignState();
        s.start();
        s.executed.put(AnomalyRegistry.WATCHER_VANISH, new ExecutionRecord(4, 100));
        s.watcherLooks = 3;
        s.fear = 50;
        assertEquals(1, WatcherEvolution.stage(s)); // 4 + 3 + 2 = 9 -> estagio 1
    }

    @Test
    void fearIsBoundedAndOnlyScalesChance() {
        CampaignState s = new CampaignState();
        for (int i = 0; i < 100; i++) FearModel.add(s, FearModel.GAIN_ANOMALY, false);
        assertEquals(100, s.fear);
        assertTrue(FearModel.chanceMultiplier(100) <= 1.45 + 1e-9);
        assertTrue(FearModel.chanceMultiplier(0) >= 0.85 - 1e-9);
        assertTrue(FearModel.chanceMultiplier(-50) >= 0.85 - 1e-9);
        CampaignState a = new CampaignState(), b = new CampaignState();
        FearModel.add(a, 10, false);
        FearModel.add(b, 10, true);
        assertTrue(b.fear < a.fear, "amuleto reduz o ganho");
        s.fear = 10;
        s.elapsedTicks = FearModel.DECAY_INTERVAL;
        FearModel.tick(s, false);
        assertEquals(9, s.fear);
        s.elapsedTicks = FearModel.DECAY_INTERVAL_CHARM;
        FearModel.tick(s, true);
        assertEquals(8, s.fear);
        s.fear = 0;
        FearModel.tick(s, true);
        assertEquals(0, s.fear);
    }

    @Test
    void chatTriggersMatchPortugueseAndEnglish() {
        assertEquals(ChatTriggers.WHO, ChatTriggers.match("Quem é você?"));
        assertEquals(ChatTriggers.WHO, ChatTriggers.match("who are you"));
        assertEquals(ChatTriggers.HELP, ChatTriggers.match("SOCORRO!!!"));
        assertEquals(ChatTriggers.HELP, ChatTriggers.match("please help"));
        assertEquals(ChatTriggers.HELLO, ChatTriggers.match("oi"));
        assertEquals(ChatTriggers.HELLO, ChatTriggers.match("Olá, tem alguém aí?".replace("tem alguém aí", "alguem ai")));
        assertEquals(ChatTriggers.LEAVE, ChatTriggers.match("eu quero sair daqui"));
        assertEquals(ChatTriggers.SECRET, ChatTriggers.match("Algo está errado"));
        assertEquals(ChatTriggers.SECRET, ChatTriggers.match("something is wrong, hi"));
        assertNull(ChatTriggers.match("vamos minerar diamantes"));
        assertNull(ChatTriggers.match("ohio"));      // "oi" so conta como palavra inteira
        assertNull(ChatTriggers.match("   "));
        assertNull(ChatTriggers.match(null));
    }

    @Test
    void newStateFieldsPersistAndReset() {
        CampaignState s = new CampaignState();
        s.start();
        s.fear = 37;
        s.chatReplies = 4;
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(20);
        assertEquals(37, r.fear);
        assertEquals(4, r.chatReplies);
        r.fear = 500;
        r.chatReplies = -3;
        r.validate(20);
        assertEquals(100, r.fear);
        assertEquals(0, r.chatReplies);
        r.reset();
        assertEquals(0, r.fear);
        assertEquals(0, r.chatReplies);
    }

    @Test
    void blockedDimensionsAreSanitized() {
        ModSettings c = new ModSettings();
        assertTrue(c.chatResponses);
        c.blockedDimensions.add("minecraft:the_end");
        c.blockedDimensions.add("  ");
        assertFalse(c.sanitize().isEmpty());
        assertEquals(1, c.blockedDimensions.size());
        c.blockedDimensions = null;
        c.sanitize();
        assertNotNull(c.blockedDimensions);
    }

    @Test
    void itemResourcesExist() {
        for (String id : new String[]{"torn_diary", "glass_eye", "silence_charm"}) {
            assertTrue(res("/assets/somethingiswrong/models/item/" + id + ".json"), "modelo " + id);
            assertTrue(res("/assets/somethingiswrong/textures/item/" + id + ".png"), "textura " + id);
        }
        assertTrue(res("/data/somethingiswrong/recipe/glass_eye.json"));
        assertTrue(res("/data/somethingiswrong/recipe/silence_charm.json"));
        assertTrue(res("/data/somethingiswrong/tags/block/hissable.json"));
        for (int i = 0; i <= 3; i++) {
            assertTrue(res("/assets/somethingiswrong/textures/entity/the_watcher" + (i == 0 ? "" : "_" + i) + ".png"), "estagio " + i);
        }
    }

    @Test
    void longCampaignsScaleDensityAndRescaleProgress() {
        ModSettings shortCfg = new ModSettings();
        ModSettings longCfg = new ModSettings();
        longCfg.campaignMinutes = 600; // 10 horas
        assertEquals(1.0, AnomalyScheduler.scaleFactor(shortCfg));
        assertTrue(AnomalyScheduler.scaleFactor(longCfg) > 5.0);
        assertTrue(AnomalyScheduler.globalGapTicks(longCfg) > 4 * AnomalyScheduler.globalGapTicks(shortCfg));
        AnomalyDefinition d = AnomalyRegistry.get(AnomalyRegistry.FOOTSTEPS);
        assertTrue(AnomalyScheduler.maxRepeatsFor(d, longCfg) > 4 * AnomalyScheduler.maxRepeatsFor(d, shortCfg));
        assertTrue(AnomalyScheduler.cooldownFor(d, longCfg) > 4 * AnomalyScheduler.cooldownFor(d, shortCfg));
        // reescala: mesma fracao do progresso, sem pular de fase
        CampaignState st = new CampaignState();
        st.start();
        st.lengthMinutes = 20;
        st.elapsedTicks = 12 * 60 * 20; // 12 min de 20 = 60%
        st.lastAnyEventTick = 1000;
        st.executed.put("x", new ExecutionRecord(1, 2000));
        Phase before = CampaignClock.phaseOf(st, shortCfg);
        assertTrue(CampaignClock.syncLength(st, 600));
        assertEquals(before, CampaignClock.phaseOf(st, longCfg));
        assertEquals(600, st.lengthMinutes);
        assertEquals(30000, st.lastAnyEventTick);
        assertEquals(60000, st.executed.get("x").lastTick);
        assertFalse(CampaignClock.syncLength(st, 600));
        // saves antigos (length desconhecido) so adotam o valor
        CampaignState old = new CampaignState();
        old.start();
        old.elapsedTicks = 5000;
        assertFalse(CampaignClock.syncLength(old, 120));
        assertEquals(5000, old.elapsedTicks);
        assertEquals(120, old.lengthMinutes);
    }

    @Test
    void settingsAllowUpToTwelveHours() {
        ModSettings c = new ModSettings();
        c.campaignMinutes = 720;
        assertTrue(c.sanitize().isEmpty());
        c.campaignMinutes = 5000;
        c.sanitize();
        assertEquals(720, c.campaignMinutes);
        assertTrue(c.phantomPlayer && c.epilogue);
    }

    @Test
    void epilogueOnlyUsesSafeNonScriptedEvents() {
        ModSettings cfg = new ModSettings();
        List<AnomalyDefinition> ok = AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm());
        assertFalse(ok.isEmpty());
        for (AnomalyDefinition d : ok) {
            assertFalse(d.scripted);
            assertNotEquals(AnomalyRegistry.FINALE, d.id);
        }
        assertTrue(AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm().withInCombat(true)).isEmpty());
        cfg.epilogue = false;
        assertTrue(AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm()).isEmpty());
        cfg.epilogue = true;
        cfg.enabled = false;
        assertTrue(AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm()).isEmpty());
        // eventos que exigem estar ao ar livre ou em caverna respeitam o contexto
        cfg.enabled = true;
        boolean tunnelUnderground = false, tunnelOutdoors = false;
        for (AnomalyDefinition d : AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm().withUnderground(true)))
            if (d.id.equals(AnomalyRegistry.TUNNEL)) tunnelUnderground = true;
        for (AnomalyDefinition d : AnomalyScheduler.epilogueCandidates(cfg, SafetyContext.calm()))
            if (d.id.equals(AnomalyRegistry.TUNNEL)) tunnelOutdoors = true;
        assertTrue(tunnelUnderground);
        assertFalse(tunnelOutdoors);
    }

    @Test
    void lengthPersistsInState() {
        CampaignState s = new CampaignState();
        s.start();
        s.validate(120);
        assertEquals(120, s.lengthMinutes);
        CampaignState r = CampaignState.fromMap(s.toMap());
        r.validate(60);
        assertEquals(120, r.lengthMinutes);
        r.reset();
        assertEquals(0, r.lengthMinutes);
    }
}
